/**
 * Clean database script - Direct PostgreSQL connection
 * WARNING: This will delete all data!
 */

const { Pool } = require('pg');
const logger = require('./utils/logger');

async function cleanDatabase() {
    const pool = new Pool({
        host: process.env.DB_HOST || 'localhost',
        port: process.env.DB_PORT || 5432,
        user: process.env.DB_USER || 'postgres',
        password: process.env.DB_PASSWORD || 'postgres',
        database: process.env.DB_NAME || 'crystalmath'
    });

    try {
        logger.info('Connecting to database...');
        logger.info(`Host: ${process.env.DB_HOST || 'localhost'}`);
        logger.info(`Database: ${process.env.DB_NAME || 'crystalmath'}`);

        // Test connection
        await pool.query('SELECT NOW()');
        logger.info('✓ Connected to database');

        // List of tables to clean (in order to handle foreign keys)
        const tablesToClean = [
            'audit_log',
            'redemption_queue',
            'pending_beacon_upgrades',
            'crystal_status_history',
            'crystals',
            'beacons',
            'player_wallets'
        ];

        let totalDeleted = 0;

        for (const table of tablesToClean) {
            try {
                const result = await pool.query(`DELETE FROM ${table}`);
                const count = result?.rowCount || 0;
                totalDeleted += count;
                logger.info(`✓ Cleaned ${table}: ${count} rows deleted`);
            } catch (error) {
                // Table might not exist, that's okay
                logger.warn(`⚠ Skipped ${table}: ${error.message}`);
            }
        }

        // Reset sequences (auto-increment IDs)
        try {
            const seqResult = await pool.query(`
                SELECT sequence_name
                FROM information_schema.sequences
                WHERE sequence_schema = 'public'
            `);

            for (const row of seqResult.rows) {
                await pool.query(`ALTER SEQUENCE ${row.sequence_name} RESTART WITH 1`);
                logger.info(`✓ Reset sequence: ${row.sequence_name}`);
            }
        } catch (error) {
            logger.warn('Could not reset sequences:', error.message);
        }

        logger.info('');
        logger.info(`✅ Database cleaned successfully! (${totalDeleted} total rows deleted)`);
        logger.info('');
        logger.info('Next steps:');
        logger.info('1. Delete backend/testnet-data/merkle-tree.json');
        logger.info('2. Delete Minecraft server claims.json file');
        logger.info('3. Restart the backend server (npm start)');
        logger.info('4. Restart the Minecraft server with the new plugin JAR');
        logger.info('5. Start fresh with /linkwallet and /upgrade!');

        await pool.end();
        process.exit(0);
    } catch (error) {
        logger.logError(error, { context: 'Database cleanup' });
        await pool.end();
        process.exit(1);
    }
}

cleanDatabase();

require('dotenv').config();

const config = {
    // Server
    nodeEnv: process.env.NODE_ENV || 'development',
    env: process.env.NODE_ENV || 'development',
    port: parseInt(process.env.PORT) || 3000,
    apiSecret: process.env.API_SECRET || 'change_this_secret',

    // Database
    database: {
        type: process.env.DB_TYPE || 'mysql',
        host: process.env.DB_HOST || 'localhost',
        port: parseInt(process.env.DB_PORT) || 3306,
        name: process.env.DB_NAME || 'crystalmath',
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || '',
        connectionLimit: 10
    },

    // Blockchain
    blockchain: {
        rpcUrl: process.env.PULSECHAIN_RPC_URL || 'https://rpc.pulsechain.com',
        chainId: parseInt(process.env.CHAIN_ID) || 369
    },

    // Contracts
    contracts: {
        crystalRedemption: process.env.CONTRACT_ADDRESS,
        crystal: process.env.CONTRACT_ADDRESS, // Alias for backward compatibility
        pDAI: process.env.PDAI_ADDRESS,
        WPLS: process.env.WPLS_ADDRESS || '0xA1077a294dDE1B09bB078844df40758a5D0f9a27',
        pulseXRouter: process.env.PULSEX_ROUTER_ADDRESS || '0x98bf93ebf5c380C0e6Ae8e192A7e2AE08edAcc02'
    },

    // Server Wallet
    serverWallet: {
        privateKey: process.env.SERVER_PRIVATE_KEY,
        address: process.env.SERVER_ADDRESS
    },

    // Plugin API (Minecraft server communication)
    pluginApi: process.env.PLUGIN_SERVER_URL || process.env.PLUGIN_API_URL || 'http://localhost:8080',
    pluginApiKey: process.env.PLUGIN_API_KEY || 'change_this_plugin_key',

    // Price Feeds
    prices: {
        pDAI: parseFloat(process.env.PDAI_PRICE_USD) || 0.0013,
        PLS: parseFloat(process.env.PLS_PRICE_USD) || 0.0001
    },

    // Beacon Registration & Crystal Economics
    beaconRegistration: {
        costUSD: parseFloat(process.env.BEACON_REGISTRATION_COST_USD) || 9.00,
        crystalPricePDAI: parseFloat(process.env.CRYSTAL_PRICE_PDAI) || 50,
        geodeShare: 0.67,  // 67% goes to immediate geode crystals
        lpShare: 0.33      // 33% goes to LP for monthly emissions
    },

    // Gas Settings
    gas: {
        maxPercentage: parseInt(process.env.MAX_GAS_PERCENTAGE) || 9,
        estimatedGas: parseInt(process.env.ESTIMATED_GAS) || 85000,
        maxGwei: parseInt(process.env.MAX_GAS_GWEI) || 96
    },

    // Rate Limiting
    rateLimit: {
        windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 3600000,
        maxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 10
    },

    // Security
    security: {
        jwtSecret: process.env.JWT_SECRET || 'change_this_jwt_secret',
        jwtExpiresIn: process.env.JWT_EXPIRES_IN || '24h',
        bcryptRounds: parseInt(process.env.BCRYPT_ROUNDS) || 10
    },

    // Logging
    logging: {
        level: process.env.LOG_LEVEL || 'info',
        file: process.env.LOG_FILE || 'logs/app.log'
    },

    // Merkle Tree
    merkleTree: {
        file: process.env.MERKLE_TREE_FILE || 'data/merkle-tree.json'
    },

    // Admin
    admin: {
        username: process.env.ADMIN_USERNAME || 'admin',
        password: process.env.ADMIN_PASSWORD || 'm4th'
    }
};

// Validation
function validateConfig() {
    const required = [
        'contracts.crystal',
        'contracts.pDAI',
        'serverWallet.privateKey',
        'serverWallet.address'
    ];

    const missing = required.filter(key => {
        const value = key.split('.').reduce((obj, k) => obj?.[k], config);
        return !value || value === '0x0000000000000000000000000000000000000000' || value === '0x0000000000000000000000000000000000000000000000000000000000000000';
    });

    if (missing.length > 0 && config.env === 'production') {
        throw new Error(`Missing required configuration: ${missing.join(', ')}`);
    }
}

// Validate on load
if (config.env !== 'test') {
    validateConfig();
}

module.exports = config;

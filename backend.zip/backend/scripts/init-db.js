const db = require('../services/databaseService');
const logger = require('../utils/logger');
require('dotenv').config();

/**
 * Database Initialization Script for CrystalMath Backend
 *
 * This script creates all required database tables for the CrystalMath backend.
 * Run this once after setting up your PostgreSQL/MySQL database.
 *
 * Usage: node scripts/init-db.js
 */

const POSTGRES_SCHEMA = [
    // 1. Crystals table
    `CREATE TABLE IF NOT EXISTS crystals (
        id VARCHAR(66) PRIMARY KEY,
        beacon_id VARCHAR(255) NOT NULL,
        owner_user_id VARCHAR(255) NOT NULL,
        owner_address VARCHAR(42),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        redeemed BOOLEAN DEFAULT FALSE,
        redeemed_at TIMESTAMP NULL,
        redemption_tx_hash VARCHAR(66)
    );`,
    `CREATE INDEX IF NOT EXISTS idx_crystals_owner ON crystals(owner_user_id);`,
    `CREATE INDEX IF NOT EXISTS idx_crystals_beacon ON crystals(beacon_id);`,
    `CREATE INDEX IF NOT EXISTS idx_crystals_redeemed ON crystals(redeemed);`,

    // 2. Beacons table
    `CREATE TABLE IF NOT EXISTS beacons (
        id VARCHAR(255) PRIMARY KEY,
        owner_user_id VARCHAR(255) NOT NULL,
        owner_address VARCHAR(42),
        location_world VARCHAR(255),
        location_x INT,
        location_y INT,
        location_z INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        active BOOLEAN DEFAULT TRUE,
        registered_onchain BOOLEAN DEFAULT FALSE,
        onchain_id VARCHAR(66),
        registration_tx_hash VARCHAR(66)
    );`,
    `CREATE INDEX IF NOT EXISTS idx_beacons_owner ON beacons(owner_user_id);`,
    `CREATE INDEX IF NOT EXISTS idx_beacons_active ON beacons(active);`,
    `CREATE INDEX IF NOT EXISTS idx_beacons_registered ON beacons(registered_onchain);`,

    // 3. Player wallets table
    `CREATE TABLE IF NOT EXISTS player_wallets (
        player_uuid VARCHAR(255) PRIMARY KEY,
        wallet_address VARCHAR(42) NOT NULL UNIQUE,
        linked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );`,
    `CREATE INDEX IF NOT EXISTS idx_player_wallets_address ON player_wallets(wallet_address);`,

    // 4. Redemption queue table (create enum type first if it doesn't exist)
    `DO $$ BEGIN
        CREATE TYPE redemption_status AS ENUM ('pending', 'queued', 'processing', 'completed', 'failed');
    EXCEPTION
        WHEN duplicate_object THEN null;
    END $$;`,
    `CREATE TABLE IF NOT EXISTS redemption_queue (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        crystal_id VARCHAR(66) NOT NULL,
        beacon_id VARCHAR(255) NOT NULL,
        landowner_address VARCHAR(42) NOT NULL,
        user_address VARCHAR(42) NOT NULL,
        status redemption_status DEFAULT 'pending',
        requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        processed_at TIMESTAMP NULL,
        tx_hash VARCHAR(66),
        error_message TEXT,
        gas_check JSONB
    );`,
    `CREATE INDEX IF NOT EXISTS idx_redemption_queue_status ON redemption_queue(status);`,
    `CREATE INDEX IF NOT EXISTS idx_redemption_queue_user ON redemption_queue(user_id);`,
    `CREATE INDEX IF NOT EXISTS idx_redemption_queue_crystal ON redemption_queue(crystal_id);`,
    `CREATE INDEX IF NOT EXISTS idx_redemption_queue_requested ON redemption_queue(requested_at);`,

    // 5. Redemption logs table
    `CREATE TABLE IF NOT EXISTS redemption_logs (
        id SERIAL PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        crystal_id VARCHAR(66) NOT NULL,
        event_type VARCHAR(50) NOT NULL,
        ip_address VARCHAR(45),
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        details JSONB
    );`,
    `CREATE INDEX IF NOT EXISTS idx_redemption_logs_user ON redemption_logs(user_id);`,
    `CREATE INDEX IF NOT EXISTS idx_redemption_logs_crystal ON redemption_logs(crystal_id);`,
    `CREATE INDEX IF NOT EXISTS idx_redemption_logs_event_type ON redemption_logs(event_type);`,
    `CREATE INDEX IF NOT EXISTS idx_redemption_logs_timestamp ON redemption_logs(timestamp);`
];

const MYSQL_SCHEMA = [
    // 1. Crystals table
    `CREATE TABLE IF NOT EXISTS crystals (
        id VARCHAR(66) PRIMARY KEY COMMENT 'bytes32 crystal ID (0x...)',
        beacon_id VARCHAR(255) NOT NULL COMMENT 'UUID of beacon where crystal was found',
        owner_user_id VARCHAR(255) NOT NULL COMMENT 'Minecraft player UUID who owns this crystal',
        owner_address VARCHAR(42) COMMENT 'Ethereum address of owner (linked wallet)',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        redeemed BOOLEAN DEFAULT FALSE,
        redeemed_at TIMESTAMP NULL,
        redemption_tx_hash VARCHAR(66) COMMENT 'Transaction hash of redemption',
        INDEX idx_owner (owner_user_id),
        INDEX idx_beacon (beacon_id),
        INDEX idx_redeemed (redeemed)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Stores all generated crystals';`,

    // 2. Beacons table
    `CREATE TABLE IF NOT EXISTS beacons (
        id VARCHAR(255) PRIMARY KEY COMMENT 'Beacon UUID from Minecraft',
        owner_user_id VARCHAR(255) NOT NULL COMMENT 'Minecraft player UUID who owns the land',
        owner_address VARCHAR(42) COMMENT 'Ethereum address of landowner',
        location_world VARCHAR(255),
        location_x INT,
        location_y INT,
        location_z INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        active BOOLEAN DEFAULT TRUE,
        registered_onchain BOOLEAN DEFAULT FALSE COMMENT 'Whether beacon is registered on smart contract',
        onchain_id VARCHAR(66) COMMENT 'bytes32 beacon ID on-chain',
        registration_tx_hash VARCHAR(66) COMMENT 'Transaction hash of on-chain registration',
        INDEX idx_owner (owner_user_id),
        INDEX idx_active (active),
        INDEX idx_registered (registered_onchain)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Stores beacon information';`,

    // 3. Player wallets table
    `CREATE TABLE IF NOT EXISTS player_wallets (
        player_uuid VARCHAR(255) PRIMARY KEY COMMENT 'Minecraft player UUID',
        wallet_address VARCHAR(42) NOT NULL UNIQUE COMMENT 'Linked Ethereum address',
        linked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_wallet (wallet_address)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Links Minecraft players to wallet addresses';`,

    // 4. Redemption queue table
    `CREATE TABLE IF NOT EXISTS redemption_queue (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL COMMENT 'Minecraft player UUID',
        crystal_id VARCHAR(66) NOT NULL COMMENT 'Crystal being redeemed',
        beacon_id VARCHAR(255) NOT NULL COMMENT 'Beacon where crystal was found',
        landowner_address VARCHAR(42) NOT NULL COMMENT 'Address to receive landowner tax',
        user_address VARCHAR(42) NOT NULL COMMENT 'Address to receive user payout',
        status ENUM('pending', 'queued', 'processing', 'completed', 'failed') DEFAULT 'pending',
        requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        processed_at TIMESTAMP NULL,
        tx_hash VARCHAR(66) COMMENT 'Transaction hash if completed',
        error_message TEXT COMMENT 'Error message if failed',
        gas_check JSON COMMENT 'Gas check data when queued',
        INDEX idx_status (status),
        INDEX idx_user (user_id),
        INDEX idx_crystal (crystal_id),
        INDEX idx_requested (requested_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Queue for redemption requests';`,

    // 5. Redemption logs table
    `CREATE TABLE IF NOT EXISTS redemption_logs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id VARCHAR(255) NOT NULL,
        crystal_id VARCHAR(66) NOT NULL,
        event_type VARCHAR(50) NOT NULL COMMENT 'ownership_failed, queued, pending, completed, failed',
        ip_address VARCHAR(45),
        timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        details JSON COMMENT 'Additional event details',
        INDEX idx_user (user_id),
        INDEX idx_crystal (crystal_id),
        INDEX idx_event_type (event_type),
        INDEX idx_timestamp (timestamp)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Audit log for all redemption attempts';`
];

async function initializeDatabase() {
    console.log('\n🗄️  CrystalMath Database Initialization\n');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

    try {
        // Load configuration
        const config = require('../config/config');
        console.log(`📋 Database Type: ${config.database.type}`);
        console.log(`📋 Database Name: ${config.database.name}`);
        console.log(`📋 Database Host: ${config.database.host}:${config.database.port}`);
        console.log('');

        // Connect to database
        console.log('⏳ Connecting to database...');
        await db.connect();
        console.log('✅ Database connected\n');

        // Determine which schema to use
        const schema = db.type === 'mysql' ? MYSQL_SCHEMA : POSTGRES_SCHEMA;
        console.log(`📝 Using ${db.type.toUpperCase()} schema`);
        console.log(`📝 Creating ${db.type === 'postgres' ? '5' : '5'} tables...\n`);

        // Execute schema statements
        for (let i = 0; i < schema.length; i++) {
            const statement = schema[i].trim();
            if (statement) {
                await db.query(statement);
            }
        }

        console.log('✅ All tables created successfully\n');

        // Verify tables
        console.log('🔍 Verifying database schema...\n');

        let tables;
        if (db.type === 'mysql') {
            tables = await db.query('SHOW TABLES');
            console.log('📊 Database tables:');
            tables.forEach(row => {
                const tableName = Object.values(row)[0];
                console.log(`   ✓ ${tableName}`);
            });
        } else {
            tables = await db.query(`
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = 'public'
                AND table_type = 'BASE TABLE'
                ORDER BY table_name
            `);
            console.log('📊 Database tables:');
            tables.forEach(row => {
                console.log(`   ✓ ${row.table_name}`);
            });
        }

        console.log('');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('✅ Database initialization complete!');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

        console.log('📋 Next steps:');
        console.log('   1. Start the backend server: npm start');
        console.log('   2. Configure Minecraft plugin with backend URL');
        console.log('   3. Test the connection: curl http://localhost:3000/health\n');

        // Close connection
        await db.close();
        process.exit(0);

    } catch (error) {
        console.error('\n❌ Database initialization failed:\n');
        console.error(error.message);
        console.error('');
        console.error('💡 Troubleshooting:');
        console.error('   1. Ensure PostgreSQL/MySQL is running');
        console.error('   2. Check database credentials in backend/.env');
        console.error('   3. Verify database exists: CREATE DATABASE crystalmath_testnet;');
        console.error('   4. Check database user permissions\n');

        if (error.stack) {
            console.error('Stack trace:');
            console.error(error.stack);
        }

        process.exit(1);
    }
}

// Run initialization
initializeDatabase();

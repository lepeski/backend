const { Client } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function runMigration() {
    const client = new Client({
        host: process.env.DB_HOST || 'localhost',
        port: process.env.DB_PORT || 5432,
        database: process.env.DB_NAME || 'crystalmath_testnet',
        user: process.env.DB_USER || 'postgres',
        password: process.env.DB_PASSWORD
    });

    try {
        await client.connect();
        console.log('Connected to database');

        const sql = fs.readFileSync(path.join(__dirname, 'migrations/add_pending_upgrades.sql'), 'utf8');

        console.log('Running migration...');
        await client.query(sql);

        console.log('✅ Migration completed successfully!');

        // Verify tables
        const result = await client.query(`
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = 'public'
            AND table_name = 'pending_upgrades'
        `);

        if (result.rows.length > 0) {
            console.log('✅ pending_upgrades table created');
        }

        // Check constraint
        const constraint = await client.query(`
            SELECT constraint_name
            FROM information_schema.table_constraints
            WHERE table_name = 'player_wallets'
            AND constraint_name = 'unique_wallet_address'
        `);

        if (constraint.rows.length > 0) {
            console.log('✅ unique_wallet_address constraint added');
        }

    } catch (error) {
        console.error('Migration failed:', error.message);
        process.exit(1);
    } finally {
        await client.end();
    }
}

runMigration();

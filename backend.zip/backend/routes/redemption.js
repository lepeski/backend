const express = require('express');
const router = express.Router();
const redemptionService = require('../services/redemptionService');
const db = require('../services/databaseService');
const logger = require('../utils/logger');
const { validateRedemption, handleValidationErrors } = require('../middleware/validation');
const { redemptionLimiter } = require('../middleware/rateLimit');
const { authenticatePlugin } = require('../middleware/auth');

/**
 * POST /api/redeem
 * Process crystal redemption SYNCHRONOUSLY in real-time (2-5 seconds)
 * SECURITY: Requires plugin authentication + inventory verification
 *
 * NEW FLOW (Sprint 2):
 * 1. Verify player has crystal in inventory
 * 2. Lock crystal (make undroppable)
 * 3. Mark as REDEEMING in database
 * 4. Submit blockchain transaction
 * 5. Wait for confirmation
 * 6. Remove crystal from inventory
 * 7. Return transaction hash
 *
 * On error: Rollback (unlock crystal, restore state)
 */
router.post('/redeem',
    authenticatePlugin,
    redemptionLimiter,
    validateRedemption,
    handleValidationErrors,
    async (req, res) => {
        const { userId, crystalId, beaconId } = req.body;

        try {
            logger.info(`Redemption request: user=${userId}, crystal=${crystalId}, beacon=${beaconId}`);

            // Process redemption synchronously using new service
            const result = await redemptionService.processRedemption(
                userId,
                crystalId,
                beaconId,
                req.ip
            );

            if (result.success) {
                // Success - return transaction hash
                logger.info(`Redemption successful: ${result.txHash} (${result.duration}ms)`);

                return res.json({
                    success: true,
                    message: 'Crystal redeemed successfully!',
                    txHash: result.txHash,
                    explorerUrl: result.explorerUrl,
                    duration: result.duration
                });
            } else {
                // Failed - return error with code
                logger.warn(`Redemption failed: ${result.error}`, { userId, crystalId, code: result.code });

                // Map error code to HTTP status
                const statusCode = {
                    'NOT_FOUND': 404,
                    'ALREADY_REDEEMED': 410,
                    'IN_PROGRESS': 409,
                    'BEACON_INACTIVE': 400,
                    'PLAYER_OFFLINE': 400,
                    'NO_POSSESSION': 403,
                    'NO_WALLET': 400,
                    'PROOF_FAILED': 500,
                    'TX_FAILED': 500,
                    'LOCK_FAILED': 500,
                    'UNKNOWN': 500
                }[result.code] || 500;

                return res.status(statusCode).json({
                    success: false,
                    error: result.error,
                    code: result.code
                });
            }

        } catch (error) {
            logger.logError(error, {
                context: 'Redemption request',
                userId,
                crystalId,
                beaconId
            });

            return res.status(500).json({
                success: false,
                error: 'Internal server error. Please try again.',
                code: 'INTERNAL_ERROR'
            });
        }
    }
);

/**
 * GET /api/redemption/status/:crystalId
 * Get crystal redemption status (NEW - uses crystal status, not queue)
 */
router.get('/status/:crystalId', async (req, res) => {
    try {
        const { crystalId } = req.params;

        const status = await redemptionService.getRedemptionStatus(crystalId);

        if (!status.exists) {
            return res.status(404).json({
                error: status.error || 'Crystal not found'
            });
        }

        res.json(status);

    } catch (error) {
        logger.logError(error, { context: 'Get redemption status' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * POST /api/redemption/cleanup
 * Cleanup stuck REDEEMING crystals (admin/cron endpoint)
 */
router.post('/cleanup', async (req, res) => {
    try {
        const { maxAgeMinutes } = req.body;

        const result = await redemptionService.cleanupStuckRedemptions(maxAgeMinutes || 30);

        res.json(result);

    } catch (error) {
        logger.logError(error, { context: 'Cleanup stuck redemptions' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;

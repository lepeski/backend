const express = require('express');
const router = express.Router();
const { ethers } = require('ethers');
const db = require('../services/databaseService');
const contractService = require('../services/contractService');
const signatureService = require('../services/signatureService');
const config = require('../config/config');
const logger = require('../utils/logger');
const { validateBeaconRegistration, validateBeaconBatch, handleValidationErrors } = require('../middleware/validation');
const { apiLimiter } = require('../middleware/rateLimit');
const { authenticatePlugin } = require('../middleware/auth');

/**
 * Helper function to convert beacon UUID to bytes32
 */
function generateBeaconId(beaconUUID) {
    return ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(['string'], [beaconUUID]));
}

/**
 * Calculate beacon registration economics
 * Based on c_calc.pyw formula
 */
function calculateBeaconEconomics(costUSD, pdaiPriceUSD, crystalPricePDAI) {
    // Convert USD cost to pDAI
    const landPDAI = costUSD / pdaiPriceUSD;

    // Geode share (67%) - immediate crystals (rounded UP to whole crystals)
    const geodeTargetPDAI = config.beaconRegistration.geodeShare * landPDAI;
    const geodeCrystals = Math.ceil(geodeTargetPDAI / crystalPricePDAI);
    const geodeNowPDAI = geodeCrystals * crystalPricePDAI;

    // LP share (33%) - for monthly emissions
    const lpWalletPDAI = landPDAI - geodeNowPDAI;

    return {
        landPDAI: Math.floor(landPDAI * 100) / 100, // Round to 2 decimals
        geodeCrystals,
        geodeNowPDAI,
        lpWalletPDAI
    };
}

/**
 * POST /api/beacon/request-upgrade
 * Create pending upgrade - player just needs to send pDAI to contract
 * SECURITY: Requires plugin authentication
 */
router.post('/request-upgrade',
    authenticatePlugin,
    apiLimiter,
    async (req, res) => {
        const { beaconKey, playerUuid } = req.body;

        try {
            logger.info(`Upgrade request for beacon: ${beaconKey} by player: ${playerUuid}`);

            // Get player's wallet address
            const walletResult = await db.query(
                'SELECT wallet_address FROM player_wallets WHERE player_uuid = $1',
                [playerUuid]
            );

            if (!walletResult || walletResult.length === 0) {
                return res.status(400).json({
                    success: false,
                    error: 'NO_WALLET_LINKED',
                    message: 'You must link your wallet with /linkwallet before upgrading a beacon.'
                });
            }

            const walletAddress = walletResult[0].wallet_address.toLowerCase();

            // Check if player already has a pending upgrade
            const existingPending = await db.getPendingUpgradeByWallet(walletAddress);
            if (existingPending) {
                return res.status(400).json({
                    success: false,
                    error: 'PENDING_UPGRADE_EXISTS',
                    message: 'You already have a pending upgrade. Pay for it or use /cancel-upgrade first.',
                    pending: {
                        beaconKey: existingPending.beacon_key,
                        contractAddress: existingPending.contract_address,
                        amount: ethers.formatEther(existingPending.payment_amount),
                        expiresAt: existingPending.expires_at
                    }
                });
            }

            // Calculate payment details based on USD cost and live pDAI price
            const costUSD = config.beaconRegistration.costUSD;
            const pdaiPriceUSD = config.prices.pDAI;
            const crystalPricePDAI = config.beaconRegistration.crystalPricePDAI;
            const contractAddress = process.env.CONTRACT_ADDRESS;

            // Calculate economics
            const economics = calculateBeaconEconomics(costUSD, pdaiPriceUSD, crystalPricePDAI);
            const registrationCostPDAI = economics.landPDAI.toFixed(2);
            const registrationCostWei = ethers.parseEther(registrationCostPDAI);

            // Create pending upgrade
            const pending = await db.createPendingUpgrade(
                playerUuid,
                walletAddress,
                beaconKey,
                contractAddress,
                registrationCostWei.toString(),
                60 // expires in 60 minutes
            );

            logger.info(`Pending upgrade created for ${beaconKey}`, {
                wallet: walletAddress,
                beacon: beaconKey,
                amountUSD: costUSD,
                amountPDAI: registrationCostPDAI,
                crystals: economics.geodeCrystals,
                expiresAt: pending.expires_at
            });

            res.json({
                success: true,
                beaconKey,
                walletAddress,
                payment: {
                    contractAddress,
                    token: process.env.PDAI_ADDRESS,
                    amount: registrationCostWei.toString(),
                    amountUSD: costUSD,
                    amountPDAI: parseFloat(registrationCostPDAI),
                    amountFormatted: `$${costUSD.toFixed(2)} (${registrationCostPDAI} pDAI)`
                },
                crystals: {
                    immediate: economics.geodeCrystals,
                    lpReserve: economics.lpWalletPDAI.toFixed(2)
                },
                expiresAt: pending.expires_at,
                expiresInMinutes: 60,
                message: `Send exactly ${registrationCostPDAI} pDAI ($${costUSD.toFixed(2)}) to upgrade your beacon`
            });

        } catch (error) {
            logger.logError(error, { context: 'Request beacon upgrade', beaconKey, playerUuid });
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
);

/**
 * POST /api/beacon/cancel-upgrade
 * Cancel pending upgrade
 * SECURITY: Requires plugin authentication
 */
router.post('/cancel-upgrade',
    authenticatePlugin,
    apiLimiter,
    async (req, res) => {
        const { playerUuid } = req.body;

        try {
            // Get player's wallet address
            const walletResult = await db.query(
                'SELECT wallet_address FROM player_wallets WHERE player_uuid = $1',
                [playerUuid]
            );

            if (!walletResult || walletResult.length === 0) {
                return res.status(400).json({
                    success: false,
                    error: 'NO_WALLET_LINKED'
                });
            }

            const walletAddress = walletResult[0].wallet_address.toLowerCase();

            // Cancel pending upgrade
            await db.cancelPendingUpgrade(walletAddress);

            logger.info(`Pending upgrade cancelled for player ${playerUuid}`);

            res.json({
                success: true,
                message: 'Pending upgrade cancelled'
            });

        } catch (error) {
            logger.logError(error, { context: 'Cancel upgrade', playerUuid });
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
);

/**
 * POST /api/beacon/register
 * Register single beacon on-chain
 * SECURITY: Requires plugin authentication
 */
router.post('/register',
    authenticatePlugin,
    apiLimiter,
    validateBeaconRegistration,
    handleValidationErrors,
    async (req, res) => {
        const { beaconId, ownerAddress } = req.body;

        try {
            logger.info(`Registering beacon: ${beaconId}`);

            // Get beacon from database
            const beacon = await db.getBeacon(beaconId);

            if (!beacon) {
                return res.status(404).json({ error: 'Beacon not found in database' });
            }

            if (beacon.registered_onchain) {
                return res.status(400).json({ error: 'Beacon already registered on-chain' });
            }

            // Convert UUID to bytes32
            const onchainId = generateBeaconId(beaconId);

            // Register on-chain
            const result = await contractService.registerBeacon(onchainId, ownerAddress);

            // Update database
            await db.updateBeaconOnchainStatus(beaconId, onchainId);

            logger.info(`Beacon registered on-chain`, {
                beaconId,
                onchainId,
                txHash: result.txHash
            });

            res.json({
                success: true,
                beaconId,
                onchainId,
                txHash: result.txHash
            });

        } catch (error) {
            logger.logError(error, { context: 'Register beacon', beaconId });
            res.status(500).json({ error: error.message });
        }
    }
);

/**
 * POST /api/beacon/batch-register
 * Register multiple beacons on-chain (gas efficient)
 * SECURITY: Requires plugin authentication
 */
router.post('/batch-register',
    authenticatePlugin,
    apiLimiter,
    validateBeaconBatch,
    handleValidationErrors,
    async (req, res) => {
        const { beacons } = req.body;

        try {
            logger.info(`Batch registering ${beacons.length} beacons`);

            const beaconIds = [];
            const ownerAddresses = [];
            const beaconUUIDs = [];

            for (const beacon of beacons) {
                // Check if beacon exists in database
                const dbBeacon = await db.getBeacon(beacon.beaconId);

                if (!dbBeacon) {
                    logger.warn(`Beacon not found in database: ${beacon.beaconId}`);
                    continue;
                }

                if (dbBeacon.registered_onchain) {
                    logger.warn(`Beacon already registered: ${beacon.beaconId}`);
                    continue;
                }

                const onchainId = generateBeaconId(beacon.beaconId);

                beaconIds.push(onchainId);
                ownerAddresses.push(beacon.ownerAddress);
                beaconUUIDs.push(beacon.beaconId);
            }

            if (beaconIds.length === 0) {
                return res.status(400).json({ error: 'No valid beacons to register' });
            }

            // Register batch on-chain
            const result = await contractService.registerBeaconsBatch(beaconIds, ownerAddresses);

            // Update database
            for (let i = 0; i < beaconUUIDs.length; i++) {
                await db.updateBeaconOnchainStatus(beaconUUIDs[i], beaconIds[i]);
            }

            logger.info(`Batch registered ${beaconIds.length} beacons`, {
                txHash: result.txHash
            });

            res.json({
                success: true,
                count: beaconIds.length,
                txHash: result.txHash
            });

        } catch (error) {
            logger.logError(error, { context: 'Batch register beacons' });
            res.status(500).json({ error: error.message });
        }
    }
);

/**
 * GET /api/beacon/check-registration/:beaconKey
 * Check if beacon is registered on-chain by beacon key
 * Used by plugin to poll for registration confirmation
 */
router.get('/check-registration/:beaconKey',
    authenticatePlugin,
    async (req, res) => {
        const { beaconKey } = req.params;

        try {
            // Generate beacon ID from key
            const beaconId = generateBeaconId(beaconKey);

            // Check on-chain status
            const isActive = await contractService.isBeaconActive(beaconId);

            if (isActive) {
                // Get owner from contract
                const owner = await contractService.getBeaconOwner(beaconId);

                // Mark signature as used (if exists)
                signatureService.markAsUsed(beaconId);

                logger.info(`Beacon ${beaconKey} confirmed registered on-chain`, {
                    beaconId,
                    owner
                });

                res.json({
                    success: true,
                    registered: true,
                    beaconId,
                    owner
                });
            } else {
                res.json({
                    success: true,
                    registered: false,
                    beaconId
                });
            }

        } catch (error) {
            logger.logError(error, { context: 'Check beacon registration', beaconKey });
            res.status(500).json({
                success: false,
                error: error.message
            });
        }
    }
);

/**
 * GET /api/beacon/:id
 * Get beacon info
 */
router.get('/:id', async (req, res) => {
    try {
        const beacon = await db.getBeacon(req.params.id);

        if (!beacon) {
            return res.status(404).json({ error: 'Beacon not found' });
        }

        res.json(beacon);

    } catch (error) {
        logger.logError(error, { context: 'Get beacon' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/beacon/list/active
 * Get all active beacons
 */
router.get('/list/active', async (req, res) => {
    try {
        const beacons = await db.getActiveBeacons();
        res.json(beacons);
    } catch (error) {
        logger.logError(error, { context: 'Get active beacons' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
module.exports.generateBeaconId = generateBeaconId;

const express = require('express');
const router = express.Router();
const db = require('../services/databaseService');
const merkleService = require('../services/merkleService');
const contractService = require('../services/contractService');
const pluginService = require('../services/pluginService');
const merkleRootUpdateQueue = require('../services/merkleRootUpdateQueue');
const logger = require('../utils/logger');
const { validateNewCrystal, handleValidationErrors } = require('../middleware/validation');
const { apiLimiter } = require('../middleware/rateLimit');
const { authenticatePlugin } = require('../middleware/auth');

/**
 * POST /api/crystals/new
 * Notify backend of new crystal (called by Minecraft plugin)
 * SECURITY: Requires plugin authentication to prevent DoS attacks
 */
router.post('/new',
    authenticatePlugin,
    apiLimiter,
    validateNewCrystal,
    handleValidationErrors,
    async (req, res) => {
        const { crystalId } = req.body;

        try {
            logger.info(`New crystal notification: ${crystalId}`);

            // Save crystal to database (minimal record - full data in plugin DB)
            await db.saveCrystalMinimal(crystalId);

            // Schedule Merkle tree update (batched with other crystals)
            merkleRootUpdateQueue.scheduleUpdate();

            res.json({
                success: true,
                message: 'Crystal added, Merkle tree update scheduled'
            });

        } catch (error) {
            logger.logError(error, { context: 'New crystal notification', crystalId });
            res.status(500).json({ error: 'Internal server error' });
        }
    }
);

/**
 * Helper function to update Merkle tree (POSSESSION-BASED)
 * Enables PvP theft - whoever holds crystal can redeem
 */
async function updateMerkleTreeWithNewCrystals() {
    try {
        // Get all unredeemed crystals
        const crystals = await db.getAllUnredeemedCrystals();

        logger.info(`Updating Merkle tree with ${crystals.length} crystals (V3 possession-based)`);

        // If no crystals yet, skip contract update
        if (crystals.length === 0) {
            logger.info(`No crystals to add to Merkle tree yet, skipping contract update`);
            return { skipped: true, reason: 'No crystals in database' };
        }

        // Prepare crystal data WITHOUT ownership
        const crystalData = crystals.map(c => ({
            crystalId: c.id
        }));

        // Build Merkle tree WITHOUT ownership (possession-based)
        const newRoot = merkleService.buildTree(crystalData);

        // Save tree to file
        merkleService.saveToFile();

        // Update contract
        const result = await contractService.updateMerkleRoot(newRoot);

        logger.info(`Merkle root updated on-chain (V3 possession-based)`, {
            root: newRoot,
            txHash: result.txHash,
            totalCrystals: crystalData.length
        });

        return result;

    } catch (error) {
        logger.logError(error, { context: 'Update Merkle tree' });
        throw error;
    }
}

/**
 * GET /api/merkle/proof/:crystalId
 * Get Merkle proof for a crystal (POSSESSION-BASED WITH INVENTORY VERIFICATION)
 *
 * SECURITY: Enables PvP theft mechanic
 * - Proof generated for crystalId only (no owner verification)
 * - Backend verifies player has crystal in inventory (IMPLEMENTED)
 * - Whoever holds the crystal can redeem it
 * - Crystal marked as REDEEMING to prevent double-spend
 */
router.get('/merkle/proof/:crystalId', authenticatePlugin, async (req, res) => {
    try {
        const { crystalId } = req.params;
        const { userId } = req.query;

        if (!userId) {
            return res.status(400).json({ error: 'userId query parameter required' });
        }

        // 1. Verify crystal exists in database
        const crystal = await db.getCrystal(crystalId);

        if (!crystal) {
            logger.logSecurity('Proof requested for non-existent crystal', {
                crystalId,
                userId,
                ip: req.ip
            });

            await db.logAuditEvent({
                event_type: 'PROOF_REQUEST_FAILED',
                user_id: userId,
                crystal_id: crystalId,
                success: false,
                ip_address: req.ip,
                metadata: { reason: 'Crystal not found' }
            });

            return res.status(404).json({ error: 'Crystal not found' });
        }

        // 2. Check crystal status (must not be REDEEMED, REDEEMING, or LOST)
        if (crystal.status === 'REDEEMED') {
            logger.logSecurity('Proof requested for already redeemed crystal', {
                crystalId,
                userId,
                ip: req.ip
            });

            await db.logAuditEvent({
                event_type: 'PROOF_REQUEST_FAILED',
                user_id: userId,
                crystal_id: crystalId,
                success: false,
                ip_address: req.ip,
                metadata: { reason: 'Crystal already redeemed', status: crystal.status }
            });

            return res.status(410).json({ error: 'Crystal already redeemed' });
        }

        if (crystal.status === 'REDEEMING') {
            logger.logSecurity('Proof requested for crystal already being redeemed', {
                crystalId,
                userId,
                ip: req.ip
            });

            await db.logAuditEvent({
                event_type: 'PROOF_REQUEST_FAILED',
                user_id: userId,
                crystal_id: crystalId,
                success: false,
                ip_address: req.ip,
                metadata: { reason: 'Crystal already being redeemed', status: crystal.status }
            });

            return res.status(409).json({ error: 'Crystal is already being redeemed' });
        }

        if (crystal.status === 'LOST') {
            logger.logSecurity('Proof requested for lost crystal', {
                crystalId,
                userId,
                ip: req.ip
            });

            return res.status(410).json({ error: 'Crystal is lost and cannot be redeemed' });
        }

        // 3. CRITICAL: Verify player has crystal in inventory (possession check)
        const hasCrystal = await pluginService.verifyPlayerInventory(userId, crystalId);

        if (!hasCrystal) {
            logger.logSecurity('Proof requested without possession', {
                crystalId,
                userId,
                ip: req.ip,
                note: 'Player does not have crystal in inventory'
            });

            await db.logAuditEvent({
                event_type: 'PROOF_REQUEST_FAILED',
                user_id: userId,
                crystal_id: crystalId,
                success: false,
                ip_address: req.ip,
                metadata: { reason: 'No possession - crystal not in inventory' }
            });

            return res.status(403).json({
                error: 'You do not have this crystal in your inventory'
            });
        }

        // 4. Mark crystal as REDEEMING (prevents double-spend)
        await db.updateCrystalStatus(crystalId, 'REDEEMING', {
            userId,
            requestedAt: Date.now(),
            ip: req.ip
        });

        logger.info(`Crystal ${crystalId} marked as REDEEMING`, { userId });

        // 5. Generate proof WITHOUT ownership (possession-based)
        const proof = merkleService.getProof(crystalId);

        logger.info(`Merkle proof generated for crystal ${crystalId}`, {
            userId,
            note: 'Possession-based - inventory verified'
        });

        // 6. Log successful proof request
        await db.logAuditEvent({
            event_type: 'PROOF_REQUEST_SUCCESS',
            user_id: userId,
            crystal_id: crystalId,
            success: true,
            ip_address: req.ip,
            metadata: {
                proofLength: proof.length,
                status: 'REDEEMING'
            }
        });

        res.json({
            crystalId,
            proof,
            root: merkleService.getRoot()
        });

    } catch (error) {
        logger.logError(error, { context: 'Get Merkle proof', crystalId: req.params.crystalId });

        // Log error
        await db.logAuditEvent({
            event_type: 'PROOF_REQUEST_ERROR',
            user_id: req.query.userId,
            crystal_id: req.params.crystalId,
            success: false,
            error: error.message,
            ip_address: req.ip
        }).catch(err => logger.logError(err, { context: 'Log audit event failed' }));

        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
module.exports.updateMerkleTreeWithNewCrystals = updateMerkleTreeWithNewCrystals;

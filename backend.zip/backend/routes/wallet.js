const express = require('express');
const router = express.Router();
const db = require('../services/databaseService');
const logger = require('../utils/logger');
const { validateWalletLink, handleValidationErrors } = require('../middleware/validation');
const { apiLimiter } = require('../middleware/rateLimit');
const { authenticatePlugin } = require('../middleware/auth');

/**
 * POST /api/wallet/link
 * Link a player's Minecraft UUID to their wallet address
 */
router.post('/link',
    authenticatePlugin,
    apiLimiter,
    validateWalletLink,
    handleValidationErrors,
    async (req, res) => {
        const { playerUuid, walletAddress } = req.body;

        try {
            logger.info(`Linking wallet for player: ${playerUuid}`);

            // Check if player already has a linked wallet
            const existing = await db.getPlayerWallet(playerUuid);

            if (existing) {
                logger.warn(`Player ${playerUuid} already has linked wallet: ${existing.wallet_address}`);

                return res.json({
                    success: true,
                    message: 'Wallet already linked',
                    walletAddress: existing.wallet_address,
                    linkedAt: existing.linked_at
                });
            }

            // Link the wallet
            await db.linkPlayerWallet(playerUuid, walletAddress);

            logger.info(`Wallet linked successfully`, {
                playerUuid,
                walletAddress
            });

            res.json({
                success: true,
                message: 'Wallet linked successfully',
                playerUuid,
                walletAddress
            });

        } catch (error) {
            logger.logError(error, {
                context: 'Link wallet',
                playerUuid,
                walletAddress
            });

            res.status(500).json({
                error: 'Failed to link wallet'
            });
        }
    }
);

/**
 * GET /api/wallet/:playerUuid
 * Get player's linked wallet address
 */
router.get('/:playerUuid',
    authenticatePlugin,
    async (req, res) => {
        const { playerUuid } = req.params;

        try {
            const wallet = await db.getPlayerWallet(playerUuid);

            if (!wallet) {
                return res.status(404).json({
                    error: 'No wallet linked for this player'
                });
            }

            res.json({
                playerUuid,
                walletAddress: wallet.wallet_address,
                linkedAt: wallet.linked_at
            });

        } catch (error) {
            logger.logError(error, {
                context: 'Get player wallet',
                playerUuid
            });

            res.status(500).json({
                error: 'Internal server error'
            });
        }
    }
);

module.exports = router;

const express = require('express');
const router = express.Router();
const db = require('../services/databaseService');
const merkleService = require('../services/merkleService');
const contractService = require('../services/contractService');
const gasService = require('../services/gasService');
const redemptionService = require('../services/redemptionService');
const merkleRootUpdateQueue = require('../services/merkleRootUpdateQueue');
const logger = require('../utils/logger');
const { authenticateAdmin } = require('../middleware/auth');
const { adminLimiter } = require('../middleware/rateLimit');

// All admin routes require authentication
router.use(authenticateAdmin);
router.use(adminLimiter);

/**
 * POST /api/admin/process-batch
 * Process pending redemptions in batch (manual processing)
 */
router.post('/process-batch', async (req, res) => {
    const { limit = 10, skipGasCheck = false } = req.body;

    try {
        logger.info('Manual batch processing requested', { limit, skipGasCheck });

        const pending = await db.getPendingRedemptions();
        const toProcess = pending.slice(0, limit);

        if (toProcess.length === 0) {
            return res.json({
                success: true,
                message: 'No pending redemptions',
                processed: 0,
                successful: 0,
                failed: 0
            });
        }

        // Use shared redemption service
        const result = await redemptionService.processRedemptionBatch(toProcess, {
            skipGasCheck
        });

        res.json(result);

    } catch (error) {
        logger.logError(error, { context: 'Process batch' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * POST /api/admin/retry-queued
 * Retry queued redemptions (when gas drops)
 */
router.post('/retry-queued', async (req, res) => {
    try {
        logger.info('Manually retrying queued redemptions');

        // Use shared redemption service
        const result = await redemptionService.retryQueuedRedemptions();

        res.json(result);

    } catch (error) {
        logger.logError(error, { context: 'Retry queued' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/admin/stats
 * Get redemption statistics
 */
router.get('/stats', async (req, res) => {
    try {
        const stats = await db.getStats();
        const gasStats = await gasService.getGasStats();
        const contractBalance = await contractService.getContractBalance();

        res.json({
            redemptions: stats,
            gas: gasStats,
            contract: {
                balance: contractBalance
            }
        });

    } catch (error) {
        logger.logError(error, { context: 'Get stats' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * POST /api/admin/merkle/update
 * Manually trigger Merkle root update via queue (RECOMMENDED)
 * Uses the update queue to prevent concurrent transaction errors
 */
router.post('/merkle/update', async (req, res) => {
    try {
        logger.info('Manual Merkle root update requested via queue');

        // Use the queue to force an immediate update (bypasses debounce)
        await merkleRootUpdateQueue.forceUpdate();

        const stats = merkleService.getStats();

        res.json({
            success: true,
            message: 'Merkle root update completed',
            root: stats.root,
            totalCrystals: stats.totalLeaves,
            version: 'V3-possession-based'
        });

    } catch (error) {
        logger.logError(error, { context: 'Manual Merkle update' });
        res.status(500).json({ error: error.message });
    }
});

/**
 * GET /api/admin/merkle-queue/status
 * Get Merkle root update queue status
 */
router.get('/merkle-queue/status', (req, res) => {
    try {
        const status = merkleRootUpdateQueue.getStatus();
        const merkleStats = merkleService.getStats();

        res.json({
            success: true,
            queue: status,
            currentTree: merkleStats
        });
    } catch (error) {
        logger.logError(error, { context: 'Get queue status' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/admin/redemptions/pending
 * Get all pending redemptions
 */
router.get('/redemptions/pending', async (req, res) => {
    try {
        const pending = await db.getPendingRedemptions();
        res.json({ count: pending.length, redemptions: pending });
    } catch (error) {
        logger.logError(error, { context: 'Get pending redemptions' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/admin/redemptions/queued
 * Get all queued redemptions (high gas)
 */
router.get('/redemptions/queued', async (req, res) => {
    try {
        const queued = await db.getQueuedRedemptions();
        res.json({ count: queued.length, redemptions: queued });
    } catch (error) {
        logger.logError(error, { context: 'Get queued redemptions' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/admin/contract/tax-rates
 * Get current contract tax rates
 */
router.get('/contract/tax-rates', async (req, res) => {
    try {
        const rates = await contractService.getTaxRates();
        res.json(rates);
    } catch (error) {
        logger.logError(error, { context: 'Get tax rates' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * POST /api/admin/beacon/deactivate
 * Deactivate a beacon
 */
router.post('/beacon/deactivate', async (req, res) => {
    const { beaconId } = req.body;

    try {
        if (!beaconId) {
            return res.status(400).json({ error: 'beaconId is required' });
        }

        logger.info(`Deactivating beacon: ${beaconId}`);

        await db.deactivateBeacon(beaconId);

        res.json({
            success: true,
            message: 'Beacon deactivated',
            beaconId
        });

    } catch (error) {
        logger.logError(error, { context: 'Deactivate beacon', beaconId });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/admin/security/failed-attempts
 * Get recent failed redemption attempts
 */
router.get('/security/failed-attempts', async (req, res) => {
    const { hours = 24 } = req.query;

    try {
        const attempts = await db.getRecentFailedAttempts(parseInt(hours));
        res.json({ count: attempts.length, attempts });
    } catch (error) {
        logger.logError(error, { context: 'Get failed attempts' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/admin/queue/stats
 * Get detailed queue statistics
 */
router.get('/queue/stats', async (req, res) => {
    try {
        const stats = await redemptionService.getQueueStats();
        res.json(stats);
    } catch (error) {
        logger.logError(error, { context: 'Get queue stats' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/admin/auto-process/status
 * Get auto-processing configuration and status
 */
router.get('/auto-process/status', (req, res) => {
    try {
        const status = {
            autoProcessEnabled: process.env.AUTO_PROCESS_ENABLED === 'true',
            autoProcessIntervalMinutes: parseInt(process.env.AUTO_PROCESS_INTERVAL_MINUTES) || 15,
            autoProcessBatchSize: parseInt(process.env.AUTO_PROCESS_BATCH_SIZE) || 20,
            autoProcessMaxGasGwei: parseInt(process.env.AUTO_PROCESS_MAX_GAS_GWEI) || 10,
            autoRetryQueuedEnabled: process.env.AUTO_RETRY_QUEUED_ENABLED === 'true',
            autoRetryQueuedIntervalMinutes: parseInt(process.env.AUTO_RETRY_QUEUED_INTERVAL_MINUTES) || 5
        };

        res.json(status);
    } catch (error) {
        logger.logError(error, { context: 'Get auto-process status' });
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;

/**
 * Check what Merkle root the contract currently has
 */

const contractService = require('./services/contractService');
const merkleService = require('./services/merkleService');
const logger = require('./utils/logger');

async function checkContractRoot() {
    try {
        logger.info('Checking contract Merkle root...');

        // Initialize contract service
        await contractService.initialize();

        // Load local Merkle tree
        merkleService.loadFromFile();
        const localRoot = merkleService.getRoot();
        const localStats = merkleService.getStats();

        // Get on-chain root (try different possible function names)
        let onChainRoot;
        try {
            onChainRoot = await contractService.contract.getMerkleRoot();
        } catch (e) {
            try {
                onChainRoot = await contractService.contract.merkleRoot();
            } catch (e2) {
                try {
                    onChainRoot = await contractService.contract.currentMerkleRoot();
                } catch (e3) {
                    logger.error('Could not read Merkle root from contract');
                    logger.error('Available contract methods:', Object.keys(contractService.contract.interface.functions));
                    throw new Error('Cannot read Merkle root from contract');
                }
            }
        }

        logger.info('Local Merkle tree:');
        logger.info(`  Root: ${localRoot}`);
        logger.info(`  Crystals: ${localStats.totalLeaves}`);

        logger.info('On-chain Merkle root:');
        logger.info(`  Root: ${onChainRoot}`);

        if (localRoot === onChainRoot) {
            logger.info('✅ Roots match! Tree is synced.');
        } else {
            logger.warn('❌ Roots DO NOT match! Tree is out of sync.');
            logger.warn('You need to run: node backend/update-merkle-root.js');
        }

        process.exit(0);
    } catch (error) {
        logger.logError(error, { context: 'Check contract root' });
        process.exit(1);
    }
}

checkContractRoot();

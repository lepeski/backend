const rateLimit = require('express-rate-limit');
const config = require('../config/config');

// Global rate limiter (for all endpoints)
const globalLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // Max 100 requests per window
    message: 'Too many requests from this IP, please try again later',
    standardHeaders: true,
    legacyHeaders: false
});

// Strict limiter for redemption endpoints
const redemptionLimiter = rateLimit({
    windowMs: config.rateLimit.windowMs,
    max: config.rateLimit.maxRequests,
    message: 'Too many redemption requests, please try again later',
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => {
        // Rate limit by user ID if available, otherwise IP
        return req.body?.userId || req.ip;
    }
});

// Moderate limiter for general API calls
const apiLimiter = rateLimit({
    windowMs: 5 * 60 * 1000, // 5 minutes
    max: 50, // 50 requests
    message: 'Too many requests, please slow down',
    standardHeaders: true,
    legacyHeaders: false
});

// Very strict limiter for admin endpoints
const adminLimiter = rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 100, // 100 requests per hour
    message: 'Too many admin requests',
    standardHeaders: true,
    legacyHeaders: false
});

module.exports = {
    globalLimiter,
    redemptionLimiter,
    apiLimiter,
    adminLimiter
};

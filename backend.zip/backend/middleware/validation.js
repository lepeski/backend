const { body, param, validationResult } = require('express-validator');

/**
 * Validation rules for redemption request
 */
const validateRedemption = [
    body('userId').notEmpty().withMessage('userId is required'),
    body('crystalId').isUUID().withMessage('Invalid crystal ID format (must be UUID)'),
    body('payoutToken').optional().isEthereumAddress().withMessage('Invalid payout token address'),
    body('minAmountOut').optional().isNumeric().withMessage('minAmountOut must be a number')
];

/**
 * Validation rules for new crystal
 */
const validateNewCrystal = [
    body('crystalId').isUUID().withMessage('Invalid crystal ID format (must be UUID)')
];

/**
 * Validation rules for beacon registration
 */
const validateBeaconRegistration = [
    body('beaconId').notEmpty().withMessage('beaconId is required'),
    body('ownerAddress').isEthereumAddress().withMessage('Invalid owner address')
];

/**
 * Validation rules for batch beacon registration
 */
const validateBeaconBatch = [
    body('beacons').isArray({ min: 1 }).withMessage('beacons must be a non-empty array'),
    body('beacons.*.beaconId').notEmpty().withMessage('beaconId is required'),
    body('beacons.*.ownerAddress').isEthereumAddress().withMessage('Invalid owner address')
];

/**
 * Validation rules for wallet linking
 */
const validateWalletLink = [
    body('playerUuid').notEmpty().withMessage('playerUuid is required'),
    body('walletAddress').isEthereumAddress().withMessage('Invalid wallet address')
];

/**
 * Validation rules for Merkle root update
 */
const validateMerkleRoot = [
    body('merkleRoot').isHexadecimal().isLength({ min: 66, max: 66 }).withMessage('Invalid Merkle root format')
];

/**
 * Handle validation errors
 */
function handleValidationErrors(req, res, next) {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({
            error: 'Validation failed',
            details: errors.array()
        });
    }

    next();
}

module.exports = {
    validateRedemption,
    validateNewCrystal,
    validateBeaconRegistration,
    validateBeaconBatch,
    validateWalletLink,
    validateMerkleRoot,
    handleValidationErrors
};

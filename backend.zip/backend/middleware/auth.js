const config = require('../config/config');
const logger = require('../utils/logger');
const crypto = require('crypto');

/**
 * SECURITY FIX #3: HMAC request signing
 * Authenticate API requests from Minecraft plugin with request signing
 * Prevents replay attacks and request tampering
 */
function authenticateSignedRequest(req, res, next) {
    const timestamp = req.headers['x-request-timestamp'];
    const signature = req.headers['x-request-signature'];
    const apiKey = req.headers['x-api-key'];

    // Require all security headers
    if (!timestamp || !signature || !apiKey) {
        logger.logSecurity('Missing security headers', {
            ip: req.ip,
            hasTimestamp: !!timestamp,
            hasSignature: !!signature,
            hasApiKey: !!apiKey
        });
        return res.status(401).json({
            error: 'Missing security headers',
            required: ['X-Request-Timestamp', 'X-Request-Signature', 'X-API-Key']
        });
    }

    // Verify API key first (fast check)
    if (apiKey !== config.apiSecret) {
        logger.logSecurity('Invalid API key', {
            ip: req.ip,
            providedKey: apiKey.substring(0, 8) + '...'
        });
        return res.status(401).json({ error: 'Invalid API key' });
    }

    // Verify timestamp (prevent replay attacks)
    const requestTime = parseInt(timestamp);
    const currentTime = Date.now();
    const timeDiff = Math.abs(currentTime - requestTime);

    // Allow 60-second window
    const MAX_TIME_DIFF = 60 * 1000; // 60 seconds

    if (timeDiff > MAX_TIME_DIFF) {
        logger.logSecurity('Request timestamp too old/future', {
            ip: req.ip,
            requestTime,
            currentTime,
            diffSeconds: Math.floor(timeDiff / 1000)
        });
        return res.status(401).json({
            error: 'Request timestamp expired',
            maxAge: '60 seconds'
        });
    }

    // Compute expected signature
    // HMAC-SHA256(secret, method + url + timestamp + body)
    const bodyString = JSON.stringify(req.body || {});
    const message = `${req.method}${req.originalUrl}${timestamp}${bodyString}`;
    const expectedSignature = crypto
        .createHmac('sha256', config.apiSecret)
        .update(message)
        .digest('hex');

    // Constant-time comparison to prevent timing attacks
    const signatureBuffer = Buffer.from(signature, 'hex');
    const expectedBuffer = Buffer.from(expectedSignature, 'hex');

    if (signatureBuffer.length !== expectedBuffer.length ||
        !crypto.timingSafeEqual(signatureBuffer, expectedBuffer)) {
        logger.logSecurity('Invalid request signature', {
            ip: req.ip,
            method: req.method,
            url: req.originalUrl
        });
        return res.status(401).json({ error: 'Invalid request signature' });
    }

    // All checks passed
    logger.info('Authenticated signed request', {
        method: req.method,
        url: req.originalUrl,
        ip: req.ip
    });

    next();
}

/**
 * LEGACY: Simple API key authentication (INSECURE - for backward compatibility only)
 * @deprecated Use authenticateSignedRequest instead
 */
function authenticatePlugin(req, res, next) {
    const apiKey = req.headers['x-api-key'];

    if (!apiKey) {
        logger.logSecurity('Missing API key', { ip: req.ip });
        return res.status(401).json({ error: 'API key required' });
    }

    if (apiKey !== config.apiSecret) {
        logger.logSecurity('Invalid API key', {
            ip: req.ip,
            providedKey: apiKey.substring(0, 8) + '...'
        });
        return res.status(401).json({ error: 'Invalid API key' });
    }

    next();
}

/**
 * Authenticate admin requests
 * Uses basic auth
 */
function authenticateAdmin(req, res, next) {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({ error: 'Authorization required' });
    }

    // Parse Basic Auth
    const auth = Buffer.from(authHeader.split(' ')[1] || '', 'base64').toString();
    const [username, password] = auth.split(':');

    if (username !== config.admin.username || password !== config.admin.password) {
        logger.logSecurity('Failed admin login attempt', {
            ip: req.ip,
            username
        });
        return res.status(401).json({ error: 'Invalid credentials' });
    }

    logger.info('Admin authenticated', { ip: req.ip });
    next();
}

/**
 * Helper function to generate request signature (for client/plugin use)
 * @param {string} method - HTTP method (GET, POST, etc.)
 * @param {string} url - Request URL
 * @param {number} timestamp - Request timestamp (Date.now())
 * @param {object} body - Request body object
 * @param {string} secret - API secret
 * @returns {string} HMAC-SHA256 signature (hex)
 */
function generateRequestSignature(method, url, timestamp, body, secret) {
    const bodyString = JSON.stringify(body || {});
    const message = `${method}${url}${timestamp}${bodyString}`;
    return crypto
        .createHmac('sha256', secret)
        .update(message)
        .digest('hex');
}

module.exports = {
    authenticatePlugin, // Legacy - simple API key
    authenticateSignedRequest, // NEW - HMAC signing
    authenticateAdmin,
    generateRequestSignature // Helper for clients
};

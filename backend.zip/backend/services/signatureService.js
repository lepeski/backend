const logger = require('../utils/logger');
const { ethers } = require('ethers');

/**
 * SECURITY FIX #6 & #7: Signature tracking service
 * Prevents beacon front-running and signature farming
 *
 * Features:
 * - Tracks issued signatures to prevent duplicates
 * - Prevents signature farming attacks
 * - Marks signatures as used after on-chain registration
 * - Auto-cleanup of expired signatures
 */
class SignatureService {
    constructor() {
        // Map of beaconId → signature data
        this.issuedSignatures = new Map();

        // Cleanup expired signatures every 10 minutes
        this.cleanupInterval = setInterval(() => {
            this.cleanupExpiredSignatures();
        }, 10 * 60 * 1000);
    }

    /**
     * Generate and track a beacon registration signature
     * @param {string} beaconId - Beacon ID (bytes32)
     * @param {string} ownerAddress - Owner address
     * @param {number} nonce - Owner's current nonce
     * @param {number} chainId - Chain ID
     * @param {object} serverWallet - Ethers wallet/signer
     * @returns {object} Signature data {v, r, s, deadline, nonce}
     */
    async generateBeaconSignature(beaconId, ownerAddress, nonce, chainId, serverWallet) {
        try {
            // Check if signature already issued for this beacon
            if (this.issuedSignatures.has(beaconId)) {
                const existingSig = this.issuedSignatures.get(beaconId);

                // If not yet used, reject (prevent duplicate signatures)
                if (!existingSig.used && existingSig.deadline > Date.now()) {
                    logger.warn('Signature already issued for beacon', {
                        beaconId,
                        existingOwner: existingSig.ownerAddress,
                        requestedOwner: ownerAddress
                    });

                    throw new Error('Signature already issued for this beacon. Please wait for it to expire or be used.');
                }
            }

            // Generate deadline (1 hour validity)
            const deadline = Math.floor(Date.now() / 1000) + 3600;

            // Create message hash to sign
            // Must match contract's verification:
            // keccak256(abi.encodePacked(beaconId, owner, deadline, chainId, nonce))
            const messageHash = ethers.solidityPackedKeccak256(
                ['bytes32', 'address', 'uint256', 'uint256', 'uint256'],
                [beaconId, ownerAddress, deadline, chainId, nonce]
            );

            // Sign message
            const signature = await serverWallet.signMessage(ethers.getBytes(messageHash));
            const sig = ethers.Signature.from(signature);

            // Track signature
            this.issuedSignatures.set(beaconId, {
                ownerAddress,
                deadline,
                nonce,
                chainId,
                signature: {
                    v: sig.v,
                    r: sig.r,
                    s: sig.s
                },
                used: false,
                issuedAt: Date.now()
            });

            logger.info('Beacon registration signature generated', {
                beaconId,
                ownerAddress,
                deadline,
                nonce,
                chainId
            });

            return {
                beaconId,
                ownerAddress,
                deadline,
                nonce,
                chainId,
                v: sig.v,
                r: sig.r,
                s: sig.s
            };
        } catch (error) {
            logger.logError(error, {
                context: 'Generate beacon signature',
                beaconId,
                ownerAddress
            });
            throw error;
        }
    }

    /**
     * Mark signature as used (called after on-chain registration)
     * @param {string} beaconId - Beacon ID
     */
    markAsUsed(beaconId) {
        if (this.issuedSignatures.has(beaconId)) {
            const sig = this.issuedSignatures.get(beaconId);
            sig.used = true;
            sig.usedAt = Date.now();

            logger.info('Signature marked as used', {
                beaconId,
                ownerAddress: sig.ownerAddress
            });
        }
    }

    /**
     * Check if signature exists and is valid
     * @param {string} beaconId - Beacon ID
     * @returns {boolean}
     */
    isSignatureValid(beaconId) {
        if (!this.issuedSignatures.has(beaconId)) {
            return false;
        }

        const sig = this.issuedSignatures.get(beaconId);
        const now = Math.floor(Date.now() / 1000);

        return !sig.used && sig.deadline > now;
    }

    /**
     * Get signature data for beacon
     * @param {string} beaconId - Beacon ID
     * @returns {object|null} Signature data or null
     */
    getSignature(beaconId) {
        return this.issuedSignatures.get(beaconId) || null;
    }

    /**
     * Cleanup expired signatures to prevent memory leak
     */
    cleanupExpiredSignatures() {
        const now = Date.now();
        let cleaned = 0;

        for (const [beaconId, sig] of this.issuedSignatures.entries()) {
            // Remove if expired (deadline + 1 hour buffer)
            const expiryTime = (sig.deadline * 1000) + (60 * 60 * 1000);

            if (now > expiryTime) {
                this.issuedSignatures.delete(beaconId);
                cleaned++;
            }
        }

        if (cleaned > 0) {
            logger.info(`Cleaned up ${cleaned} expired signatures`, {
                remaining: this.issuedSignatures.size
            });
        }
    }

    /**
     * Get statistics
     * @returns {object} Stats
     */
    getStats() {
        const stats = {
            total: this.issuedSignatures.size,
            used: 0,
            unused: 0,
            expired: 0
        };

        const now = Math.floor(Date.now() / 1000);

        for (const sig of this.issuedSignatures.values()) {
            if (sig.used) {
                stats.used++;
            } else if (sig.deadline < now) {
                stats.expired++;
            } else {
                stats.unused++;
            }
        }

        return stats;
    }

    /**
     * Cleanup on shutdown
     */
    destroy() {
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
        }
    }
}

// Singleton instance
const signatureService = new SignatureService();

module.exports = signatureService;

const { ethers } = require('ethers');
const config = require('../config/config');
const logger = require('../utils/logger');
const db = require('./databaseService');
const contractService = require('./contractService');

/**
 * Payment Monitoring Service
 * Watches for pDAI transfers to the contract and processes beacon upgrades
 */
class PaymentMonitoringService {
    constructor() {
        this.provider = null;
        this.pdaiContract = null;
        this.isMonitoring = false;
        this.processedTxs = new Set(); // Prevent duplicate processing
        this.lastCheckedBlock = 0;
        this.pollingInterval = null;
        this.cleanupInterval = null;
    }

    /**
     * Initialize the payment monitoring service
     */
    async initialize() {
        try {
            logger.info('Initializing payment monitoring service...');

            // Connect to blockchain
            this.provider = new ethers.JsonRpcProvider(config.blockchain.rpcUrl);

            // pDAI contract (for watching Transfer events)
            const pdaiAbi = [
                'event Transfer(address indexed from, address indexed to, uint256 value)'
            ];
            this.pdaiContract = new ethers.Contract(
                config.contracts.pDAI,
                pdaiAbi,
                this.provider
            );

            logger.info('Payment monitoring service initialized');
            logger.info(`Watching pDAI: ${config.contracts.pDAI}`);
            logger.info(`Target contract: ${config.contracts.crystalRedemption}`);

        } catch (error) {
            logger.logError(error, { context: 'Payment monitoring initialization' });
            throw error;
        }
    }

    /**
     * Start monitoring for payments
     */
    async startMonitoring() {
        if (this.isMonitoring) {
            logger.warn('Payment monitoring already running');
            return;
        }

        this.isMonitoring = true;
        logger.info('🔍 Payment monitoring started (polling mode)');

        // PulseChain testnet doesn't support eth_getFilterChanges
        // Use polling instead of event listeners
        this.lastCheckedBlock = await this.provider.getBlockNumber();

        // Poll for new blocks every 10 seconds
        this.pollingInterval = setInterval(async () => {
            try {
                await this.checkForPayments();
            } catch (error) {
                logger.logError(error, { context: 'Payment polling' });
            }
        }, 10 * 1000);

        // Periodic cleanup of expired upgrades (every 5 minutes)
        this.cleanupInterval = setInterval(async () => {
            try {
                const expired = await db.cleanupExpiredUpgrades();
                if (expired.length > 0) {
                    logger.info(`Cleaned up ${expired.length} expired pending upgrades`);
                }
            } catch (error) {
                logger.logError(error, { context: 'Cleanup expired upgrades' });
            }
        }, 5 * 60 * 1000);
    }

    /**
     * Check for new Transfer events by polling
     */
    async checkForPayments() {
        const currentBlock = await this.provider.getBlockNumber();

        if (currentBlock <= this.lastCheckedBlock) {
            return; // No new blocks
        }

        // Query Transfer events from last checked block to current
        const filter = this.pdaiContract.filters.Transfer(
            null, // from any address
            config.contracts.crystalRedemption, // to our contract
            null  // any amount
        );

        const events = await this.pdaiContract.queryFilter(
            filter,
            this.lastCheckedBlock + 1,
            currentBlock
        );

        for (const event of events) {
            try {
                const txHash = event.transactionHash;

                // Prevent duplicate processing
                if (this.processedTxs.has(txHash)) {
                    continue;
                }
                this.processedTxs.add(txHash);

                const from = event.args[0];
                const value = event.args[2];

                logger.info('💰 Payment detected!', {
                    from,
                    to: config.contracts.crystalRedemption,
                    value: ethers.formatEther(value),
                    txHash,
                    block: event.blockNumber
                });

                // Process the payment
                await this.processPayment(from, value, txHash);

            } catch (error) {
                logger.logError(error, {
                    context: 'Payment event processing',
                    event: event?.transactionHash
                });
            }
        }

        this.lastCheckedBlock = currentBlock;
    }

    /**
     * Process a payment
     * @param {string} payerAddress - Address that sent payment
     * @param {BigNumber} amount - Amount paid
     * @param {string} txHash - Transaction hash
     */
    async processPayment(payerAddress, amount, txHash) {
        try {
            logger.info(`Processing payment from ${payerAddress}`);

            // Get pending upgrade for this wallet
            const pending = await db.getPendingUpgradeByWallet(payerAddress.toLowerCase());

            if (!pending) {
                logger.warn(`No pending upgrade found for wallet ${payerAddress}`);
                logger.warn(`This payment will sit in the contract but won't trigger an upgrade`);
                return;
            }

            // Verify payment amount matches expected
            const expectedAmountWei = BigInt(pending.payment_amount);
            const amountBigInt = BigInt(amount.toString());

            if (amountBigInt !== expectedAmountWei) {
                logger.warn(`Payment amount mismatch!`, {
                    expected: ethers.formatEther(expectedAmountWei),
                    received: ethers.formatEther(amount),
                    wallet: payerAddress,
                    beaconKey: pending.beacon_key
                });
                // Still process it if they sent at least the expected amount
                if (amountBigInt < expectedAmountWei) {
                    logger.error(`Payment too low, not processing upgrade`);
                    return;
                }
            }

            // Verify beacon ownership (security check)
            const walletInfo = await db.query(
                'SELECT player_uuid FROM player_wallets WHERE wallet_address = $1',
                [payerAddress.toLowerCase()]
            );

            if (!walletInfo || walletInfo.length === 0) {
                logger.error(`Wallet ${payerAddress} not linked to any player!`);
                return;
            }

            const playerUuid = walletInfo[0].player_uuid;

            if (playerUuid !== pending.player_uuid) {
                logger.error(`Security: Player UUID mismatch!`, {
                    walletOwner: playerUuid,
                    pendingOwner: pending.player_uuid
                });
                return;
            }

            logger.info(`✅ Payment verified for beacon ${pending.beacon_key}`);

            // Mark as paid in database
            await db.markUpgradeAsPaid(pending.id);

            // Register beacon on-chain
            logger.info(`Registering beacon ${pending.beacon_key} on-chain...`);

            const beaconId = this.generateBeaconId(pending.beacon_key);
            const result = await contractService.registerBeacon(beaconId, payerAddress);

            logger.info(`✅ Beacon registered on-chain!`, {
                beaconKey: pending.beacon_key,
                beaconId,
                owner: payerAddress,
                txHash: result.txHash,
                paymentTx: txHash
            });

            // Beacon will auto-upgrade in-game via polling system

        } catch (error) {
            logger.logError(error, {
                context: 'Process payment',
                payerAddress,
                amount: amount?.toString()
            });
        }
    }

    /**
     * Generate beacon ID from beacon key (same as backend/routes/beacons.js)
     */
    generateBeaconId(beaconKey) {
        return ethers.keccak256(
            ethers.AbiCoder.defaultAbiCoder().encode(['string'], [beaconKey])
        );
    }

    /**
     * Stop monitoring
     */
    stopMonitoring() {
        if (!this.isMonitoring) {
            return;
        }

        if (this.pollingInterval) {
            clearInterval(this.pollingInterval);
        }
        if (this.cleanupInterval) {
            clearInterval(this.cleanupInterval);
        }

        this.isMonitoring = false;
        logger.info('Payment monitoring stopped');
    }

    /**
     * Get monitoring status
     */
    getStatus() {
        return {
            isMonitoring: this.isMonitoring,
            processedTransactions: this.processedTxs.size
        };
    }
}

// Singleton instance
const paymentMonitoring = new PaymentMonitoringService();

module.exports = paymentMonitoring;

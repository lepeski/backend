/**
 * Merkle Root Update Queue
 *
 * Batches multiple crystal additions into a single Merkle root update
 * to prevent "could not replace existing tx" errors when multiple crystals
 * spawn simultaneously.
 *
 * How it works:
 * 1. When a crystal is added, scheduleUpdate() is called
 * 2. A 5-second timer starts (debounce)
 * 3. If more crystals are added during this time, the timer resets
 * 4. When the timer expires, all accumulated crystals are batched into
 *    a single Merkle tree update
 * 5. Only one update transaction can be in-flight at a time
 */

const merkleService = require('./merkleService');
const contractService = require('./contractService');
const db = require('./databaseService');
const logger = require('../utils/logger');

class MerkleRootUpdateQueue {
    constructor() {
        this.pending = false;           // Is an update currently processing?
        this.needsUpdate = false;       // Do we need another update after current one?
        this.updateTimer = null;        // Debounce timer
        this.retryTimer = null;         // Retry timer for failed updates
        this.debounceMs = 5000;         // 5 seconds - wait for more crystals
        this.retryMs = 10000;           // 10 seconds - retry failed updates
        this.maxRetries = 3;            // Maximum retry attempts
        this.retryCount = 0;            // Current retry count
    }

    /**
     * Schedule a Merkle root update
     * Call this whenever a new crystal is added
     */
    scheduleUpdate() {
        this.needsUpdate = true;

        // Clear existing debounce timer
        if (this.updateTimer) {
            clearTimeout(this.updateTimer);
            logger.info('Merkle update timer reset (more crystals added)');
        }

        // Set new debounce timer
        this.updateTimer = setTimeout(() => {
            this.processUpdate();
        }, this.debounceMs);

        logger.info(`Merkle root update scheduled (will process in ${this.debounceMs}ms)`);
    }

    /**
     * Process the update - rebuild tree and update on-chain
     */
    async processUpdate() {
        // Already processing?
        if (this.pending) {
            logger.info('Update already in progress, will retry after completion');
            // Schedule another update after this one completes
            this.needsUpdate = true;
            return;
        }

        // Nothing to update?
        if (!this.needsUpdate) {
            logger.info('No update needed (already processed)');
            return;
        }

        this.pending = true;
        this.needsUpdate = false;

        try {
            logger.info('Starting Merkle root update...');

            // 1. Get all HELD crystals from database
            const crystals = await db.query(`
                SELECT id as "crystalId"
                FROM crystals
                WHERE status = 'HELD'
                ORDER BY created_at ASC
            `);

            if (!crystals || crystals.length === 0) {
                logger.warn('No HELD crystals found - skipping Merkle tree update');
                this.pending = false;
                return;
            }

            logger.info(`Building Merkle tree with ${crystals.length} crystals`);

            // 2. Build Merkle tree
            const newRoot = merkleService.buildTree(crystals);

            // 3. Save to file
            merkleService.saveToFile();

            // 4. Update on-chain
            logger.info(`Updating Merkle root on-chain: ${newRoot}`);
            const result = await contractService.updateMerkleRoot(newRoot);

            if (result && result.success) {
                logger.info(`✅ Merkle root updated successfully! TxHash: ${result.txHash}`, {
                    root: newRoot,
                    crystalCount: crystals.length,
                    txHash: result.txHash
                });
                this.retryCount = 0; // Reset retry counter on success
            } else {
                throw new Error('Contract update returned unsuccessful result');
            }

        } catch (error) {
            logger.logError(error, {
                context: 'Merkle root update queue',
                retryCount: this.retryCount
            });

            // Retry logic
            if (this.retryCount < this.maxRetries) {
                this.retryCount++;
                this.needsUpdate = true;

                logger.warn(`Merkle root update failed, retry ${this.retryCount}/${this.maxRetries} in ${this.retryMs}ms`);

                this.retryTimer = setTimeout(() => {
                    this.processUpdate();
                }, this.retryMs);
            } else {
                logger.error(`❌ Merkle root update failed after ${this.maxRetries} retries!`);
                logger.error('Manual intervention required: Run "node backend/update-merkle-root.js"');
                this.retryCount = 0; // Reset for next batch
            }

        } finally {
            this.pending = false;

            // If more updates were requested while we were processing, schedule another
            if (this.needsUpdate && this.retryCount === 0) {
                logger.info('Additional updates requested, scheduling another batch...');
                this.scheduleUpdate();
            }
        }
    }

    /**
     * Force an immediate update (bypass debounce)
     * Use this for manual/admin-triggered updates
     */
    async forceUpdate() {
        if (this.updateTimer) {
            clearTimeout(this.updateTimer);
            this.updateTimer = null;
        }

        this.needsUpdate = true;
        await this.processUpdate();
    }

    /**
     * Get current queue status
     */
    getStatus() {
        return {
            pending: this.pending,
            needsUpdate: this.needsUpdate,
            hasTimer: this.updateTimer !== null,
            retryCount: this.retryCount,
            debounceMs: this.debounceMs
        };
    }

    /**
     * Clear all timers (for graceful shutdown)
     */
    shutdown() {
        if (this.updateTimer) {
            clearTimeout(this.updateTimer);
            this.updateTimer = null;
        }
        if (this.retryTimer) {
            clearTimeout(this.retryTimer);
            this.retryTimer = null;
        }
        logger.info('Merkle root update queue shut down');
    }
}

// Singleton instance
const merkleRootUpdateQueue = new MerkleRootUpdateQueue();

// Graceful shutdown
process.on('SIGINT', () => {
    merkleRootUpdateQueue.shutdown();
});

process.on('SIGTERM', () => {
    merkleRootUpdateQueue.shutdown();
});

module.exports = merkleRootUpdateQueue;

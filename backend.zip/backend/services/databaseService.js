const config = require('../config/config');
const logger = require('../utils/logger');

class DatabaseService {
    constructor() {
        this.pool = null;
        this.type = config.database.type;
    }

    async connect() {
        try {
            if (this.type === 'mysql') {
                await this.connectMySQL();
            } else if (this.type === 'postgres') {
                await this.connectPostgreSQL();
            } else {
                throw new Error(`Unsupported database type: ${this.type}`);
            }
            logger.info(`Database connected (${this.type})`);
        } catch (error) {
            logger.logError(error, { context: 'Database connection' });
            throw error;
        }
    }

    async connectMySQL() {
        const mysql = require('mysql2/promise');
        this.pool = mysql.createPool({
            host: config.database.host,
            port: config.database.port,
            user: config.database.user,
            password: config.database.password,
            database: config.database.name,
            connectionLimit: config.database.connectionLimit,
            waitForConnections: true,
            queueLimit: 0
        });
    }

    async connectPostgreSQL() {
        const { Pool } = require('pg');
        this.pool = new Pool({
            host: config.database.host,
            port: config.database.port,
            user: config.database.user,
            password: config.database.password,
            database: config.database.name,
            max: config.database.connectionLimit
        });
    }

    async query(sql, params = []) {
        try {
            if (this.type === 'mysql') {
                const [rows] = await this.pool.execute(sql, params);
                return rows;
            } else if (this.type === 'postgres') {
                // Convert MySQL-style ? placeholders to PostgreSQL $1, $2, $3...
                let paramIndex = 0;
                const pgSql = sql.replace(/\?/g, () => {
                    paramIndex++;
                    return `$${paramIndex}`;
                });
                const result = await this.pool.query(pgSql, params);
                return result.rows;
            }
        } catch (error) {
            logger.logError(error, { sql, params });
            throw error;
        }
    }

    // ============ Crystal Operations ============

    async getCrystal(crystalId) {
        const sql = `SELECT * FROM crystals WHERE id = ?`;
        const rows = await this.query(sql, [crystalId]);
        return rows[0] || null;
    }

    async getCrystalsByOwner(ownerUserId) {
        const sql = `SELECT * FROM crystals WHERE owner_user_id = ? AND redeemed = false`;
        return await this.query(sql, [ownerUserId]);
    }

    async getAllUnredeemedCrystals() {
        const sql = `SELECT * FROM crystals WHERE redeemed = false ORDER BY created_at ASC`;
        return await this.query(sql);
    }

    async insertCrystal(crystalData) {
        const sql = `
            INSERT INTO crystals (id, owner_user_id, owner_address, beacon_id, redeemed, created_at)
            VALUES (?, ?, ?, ?, false, NOW())
        `;
        await this.query(sql, [
            crystalData.id,
            crystalData.owner_user_id,
            crystalData.owner_address || null,
            crystalData.beacon_id
        ]);
        return crystalData.id;
    }

    async saveCrystalMinimal(crystalId) {
        const sql = `
            INSERT INTO crystals (id, status, redeemed, created_at)
            VALUES (?, 'HELD', false, NOW())
            ON CONFLICT (id) DO NOTHING
        `;
        await this.query(sql, [crystalId]);
        return crystalId;
    }

    async markCrystalRedeemed(crystalId, txHash) {
        const sql = `
            UPDATE crystals
            SET redeemed = true, redeemed_at = NOW(), redemption_tx_hash = ?
            WHERE id = ?
        `;
        await this.query(sql, [txHash, crystalId]);
    }

    /**
     * Update crystal status with metadata (V3 State Machine)
     * @param {string} crystalId - Crystal UUID
     * @param {string} status - New status (DORMANT, ACTIVE, HELD, REDEEMING, REDEEMED, LOST)
     * @param {object} metadata - Additional state metadata
     */
    async updateCrystalStatus(crystalId, status, metadata = {}) {
        const validStatuses = ['DORMANT', 'ACTIVE', 'HELD', 'REDEEMING', 'REDEEMED', 'LOST'];

        if (!validStatuses.includes(status)) {
            throw new Error(`Invalid crystal status: ${status}. Must be one of: ${validStatuses.join(', ')}`);
        }

        // Get current crystal for logging
        const crystal = await this.getCrystal(crystalId);
        const oldStatus = crystal?.status || 'UNKNOWN';

        const sql = `
            UPDATE crystals
            SET status = ?,
                updated_at = NOW(),
                metadata = ?
            WHERE id = ?
        `;

        await this.query(sql, [
            status,
            JSON.stringify(metadata),
            crystalId
        ]);

        logger.info(`Crystal ${crystalId} status updated: ${oldStatus} → ${status}`, metadata);

        // Log status change to audit log
        await this.logAuditEvent({
            event_type: 'STATUS_CHANGE',
            crystal_id: crystalId,
            metadata: {
                oldStatus,
                newStatus: status,
                ...metadata
            }
        });

        return { crystalId, oldStatus, newStatus: status };
    }

    /**
     * Get crystals by status
     * @param {string} status - Status to filter by
     * @returns {Array} Crystals with given status
     */
    async getCrystalsByStatus(status) {
        const sql = `SELECT * FROM crystals WHERE status = ? ORDER BY updated_at DESC`;
        return await this.query(sql, [status]);
    }

    /**
     * Get crystals stuck in REDEEMING status (for cleanup)
     * @param {number} maxAgeMinutes - Max age in minutes before considering stuck
     * @returns {Array} Stuck crystals
     */
    async getStuckRedeemingCrystals(maxAgeMinutes = 30) {
        if (this.type === 'mysql') {
            const sql = `
                SELECT * FROM crystals
                WHERE status = 'REDEEMING'
                AND updated_at < DATE_SUB(NOW(), INTERVAL ? MINUTE)
                ORDER BY updated_at ASC
            `;
            return await this.query(sql, [maxAgeMinutes]);
        } else {
            // PostgreSQL uses interval arithmetic
            const sql = `
                SELECT * FROM crystals
                WHERE status = 'REDEEMING'
                AND updated_at < NOW() - INTERVAL '1 minute' * ?
                ORDER BY updated_at ASC
            `;
            return await this.query(sql, [maxAgeMinutes]);
        }
    }

    /**
     * Get crystal history (all state changes from audit log)
     * @param {string} crystalId - Crystal UUID
     * @returns {Array} Audit log entries for crystal
     */
    async getCrystalHistory(crystalId) {
        const sql = `
            SELECT * FROM audit_log
            WHERE crystal_id = ?
            ORDER BY timestamp DESC
            LIMIT 100
        `;
        return await this.query(sql, [crystalId]);
    }

    // ============ Beacon Operations ============

    async getBeacon(beaconId) {
        const sql = `SELECT * FROM beacons WHERE id = ?`;
        const rows = await this.query(sql, [beaconId]);
        return rows[0] || null;
    }

    async getAllBeacons() {
        const sql = `SELECT * FROM beacons ORDER BY created_at ASC`;
        return await this.query(sql);
    }

    async getActiveBeacons() {
        const sql = `SELECT * FROM beacons WHERE active = true`;
        return await this.query(sql);
    }

    async insertBeacon(beaconData) {
        const sql = `
            INSERT INTO beacons (id, owner_user_id, owner_address, location_world, location_x, location_y, location_z, active, registered_onchain, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, true, false, NOW())
        `;
        await this.query(sql, [
            beaconData.id,
            beaconData.owner_user_id || null,
            beaconData.owner_address || null,
            beaconData.location_world || beaconData.world || null,
            beaconData.location_x || null,
            beaconData.location_y || null,
            beaconData.location_z || null
        ]);
        return beaconData.id;
    }

    async updateBeaconOnchainStatus(beaconId, onchainId) {
        const sql = `
            UPDATE beacons
            SET registered_onchain = true, onchain_id = ?
            WHERE id = ?
        `;
        await this.query(sql, [onchainId, beaconId]);
    }

    async deactivateBeacon(beaconId) {
        const sql = `UPDATE beacons SET active = false WHERE id = ?`;
        await this.query(sql, [beaconId]);
    }

    // ============ Player Wallet Operations ============

    async getPlayerWallet(playerUuid) {
        const sql = `SELECT * FROM player_wallets WHERE player_uuid = ?`;
        const rows = await this.query(sql, [playerUuid]);
        return rows[0] || null;
    }

    async linkPlayerWallet(playerUuid, walletAddress) {
        if (this.type === 'mysql') {
            const sql = `
                INSERT INTO player_wallets (player_uuid, wallet_address, linked_at)
                VALUES (?, ?, NOW())
                ON DUPLICATE KEY UPDATE wallet_address = ?, linked_at = NOW()
            `;
            await this.query(sql, [playerUuid, walletAddress, walletAddress]);
        } else {
            // PostgreSQL uses ON CONFLICT syntax
            const sql = `
                INSERT INTO player_wallets (player_uuid, wallet_address, linked_at)
                VALUES (?, ?, NOW())
                ON CONFLICT (player_uuid)
                DO UPDATE SET wallet_address = EXCLUDED.wallet_address, linked_at = NOW()
            `;
            await this.query(sql, [playerUuid, walletAddress]);
        }
    }

    // ============ Redemption Queue Operations ============

    async queueRedemption(redemptionData) {
        const sql = `
            INSERT INTO redemption_queue
            (user_id, crystal_id, beacon_id, landowner_address, user_address, status, requested_at, gas_check)
            VALUES (?, ?, ?, ?, ?, ?, NOW(), ?)
        `;
        const result = await this.query(sql, [
            redemptionData.user_id,
            redemptionData.crystal_id,
            redemptionData.beacon_id,
            redemptionData.landowner_address,
            redemptionData.user_address,
            redemptionData.status,
            JSON.stringify(redemptionData.gas_check || {})
        ]);
        return this.type === 'mysql' ? result.insertId : result[0].id;
    }

    async getPendingRedemptions(limit = 100) {
        const sql = `
            SELECT * FROM redemption_queue
            WHERE status = 'pending'
            ORDER BY requested_at ASC
            LIMIT ?
        `;
        return await this.query(sql, [limit]);
    }

    async getQueuedRedemptions() {
        const sql = `SELECT * FROM redemption_queue WHERE status = 'queued' ORDER BY requested_at ASC`;
        return await this.query(sql);
    }

    async updateRedemptionStatus(id, status, txHash = null, errorMessage = null) {
        const sql = `
            UPDATE redemption_queue
            SET status = ?, processed_at = ?, tx_hash = ?, error_message = ?
            WHERE id = ?
        `;
        const processedAt = (status === 'completed' || status === 'failed') ? new Date() : null;
        await this.query(sql, [status, processedAt, txHash, errorMessage, id]);
    }

    async moveQueuedToPending() {
        const sql = `UPDATE redemption_queue SET status = 'pending' WHERE status = 'queued'`;
        const result = await this.query(sql);
        return this.type === 'mysql' ? result.affectedRows : result.rowCount;
    }

    // ============ Redemption Logs ============

    async logRedemptionAttempt(logData) {
        const sql = `
            INSERT INTO redemption_logs (user_id, crystal_id, event_type, ip_address, timestamp, details)
            VALUES (?, ?, ?, ?, NOW(), ?)
        `;
        await this.query(sql, [
            logData.user_id,
            logData.crystal_id,
            logData.event_type,
            logData.ip_address,
            JSON.stringify(logData.details || {})
        ]);
    }

    async getRecentFailedAttempts(ipAddress, hoursAgo = 1) {
        if (this.type === 'mysql') {
            const sql = `
                SELECT COUNT(*) as count
                FROM redemption_logs
                WHERE ip_address = ?
                AND event_type = 'ownership_failed'
                AND timestamp > DATE_SUB(NOW(), INTERVAL ? HOUR)
            `;
            const rows = await this.query(sql, [ipAddress, hoursAgo]);
            return rows[0].count;
        } else {
            // PostgreSQL uses interval arithmetic
            const sql = `
                SELECT COUNT(*) as count
                FROM redemption_logs
                WHERE ip_address = ?
                AND event_type = 'ownership_failed'
                AND timestamp > NOW() - INTERVAL '1 hour' * ?
            `;
            const rows = await this.query(sql, [ipAddress, hoursAgo]);
            return rows[0].count;
        }
    }

    // ============ Audit Log Operations ============

    /**
     * Log an audit event
     * @param {object} eventData - Event data to log
     */
    async logAuditEvent(eventData) {
        const sql = `
            INSERT INTO audit_log
            (event_type, user_id, crystal_id, beacon_id, success, error, ip_address, metadata, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        await this.query(sql, [
            eventData.event_type,
            eventData.user_id || null,
            eventData.crystal_id || null,
            eventData.beacon_id || null,
            eventData.success !== undefined ? eventData.success : null,
            eventData.error || null,
            eventData.ip_address || null,
            JSON.stringify(eventData.metadata || {}),
            Date.now()
        ]);
    }

    /**
     * Get recent audit events
     * @param {number} hours - Hours to look back
     * @param {string} eventType - Filter by event type (optional)
     * @returns {Array} Audit log entries
     */
    async getRecentAuditEvents(hours = 24, eventType = null) {
        const since = Date.now() - (hours * 60 * 60 * 1000);

        let sql = `
            SELECT * FROM audit_log
            WHERE timestamp > ?
        `;
        const params = [since];

        if (eventType) {
            sql += ` AND event_type = ?`;
            params.push(eventType);
        }

        sql += ` ORDER BY timestamp DESC LIMIT 1000`;

        return await this.query(sql, params);
    }

    /**
     * Get audit events for a specific user
     * @param {string} userId - User ID
     * @param {number} limit - Max results
     * @returns {Array} Audit log entries
     */
    async getUserAuditEvents(userId, limit = 100) {
        const sql = `
            SELECT * FROM audit_log
            WHERE user_id = ?
            ORDER BY timestamp DESC
            LIMIT ?
        `;
        return await this.query(sql, [userId, limit]);
    }

    /**
     * Get failed redemption attempts by IP (for security monitoring)
     * @param {string} ipAddress - IP address
     * @param {number} hours - Hours to look back
     * @returns {number} Count of failed attempts
     */
    async getFailedAttemptsByIP(ipAddress, hours = 1) {
        const since = Date.now() - (hours * 60 * 60 * 1000);

        const sql = `
            SELECT COUNT(*) as count
            FROM audit_log
            WHERE ip_address = ?
            AND success = false
            AND timestamp > ?
        `;

        const rows = await this.query(sql, [ipAddress, since]);
        return rows[0].count;
    }

    // ============ Statistics ============

    async getStats() {
        const stats = {};

        // Total crystals
        const totalCrystals = await this.query(`SELECT COUNT(*) as count FROM crystals`);
        stats.totalCrystals = totalCrystals[0].count;

        // Redeemed crystals
        const redeemedCrystals = await this.query(`SELECT COUNT(*) as count FROM crystals WHERE redeemed = true`);
        stats.redeemedCrystals = redeemedCrystals[0].count;

        // Crystals by status (if status column exists)
        try {
            const statusCounts = await this.query(`
                SELECT status, COUNT(*) as count
                FROM crystals
                GROUP BY status
            `);
            stats.crystalsByStatus = {};
            statusCounts.forEach(row => {
                stats.crystalsByStatus[row.status] = row.count;
            });
        } catch (error) {
            // Status column might not exist yet (pre-migration)
            stats.crystalsByStatus = null;
        }

        // Pending redemptions
        const pendingRedemptions = await this.query(`SELECT COUNT(*) as count FROM redemption_queue WHERE status = 'pending'`);
        stats.pendingRedemptions = pendingRedemptions[0].count;

        // Queued redemptions
        const queuedRedemptions = await this.query(`SELECT COUNT(*) as count FROM redemption_queue WHERE status = 'queued'`);
        stats.queuedRedemptions = queuedRedemptions[0].count;

        // Completed redemptions
        const completedRedemptions = await this.query(`SELECT COUNT(*) as count FROM redemption_queue WHERE status = 'completed'`);
        stats.completedRedemptions = completedRedemptions[0].count;

        // Active beacons
        const activeBeacons = await this.query(`SELECT COUNT(*) as count FROM beacons WHERE active = true`);
        stats.activeBeacons = activeBeacons[0].count;

        // Recent audit events (last 24 hours)
        try {
            const recentEvents = await this.query(`
                SELECT COUNT(*) as count
                FROM audit_log
                WHERE timestamp > ?
            `, [Date.now() - (24 * 60 * 60 * 1000)]);
            stats.recentAuditEvents = recentEvents[0].count;
        } catch (error) {
            // Audit log table might not exist yet (pre-migration)
            stats.recentAuditEvents = null;
        }

        return stats;
    }

    // ============ Pending Upgrades ============

    /**
     * Create pending upgrade request
     * @param {string} playerUuid - Player UUID
     * @param {string} walletAddress - Player's wallet address
     * @param {string} beaconKey - Beacon key to upgrade
     * @param {string} contractAddress - Contract address for payment
     * @param {string} paymentAmount - Payment amount in wei (as string)
     * @param {number} expiresInMinutes - Expiration time in minutes
     * @returns {Promise<Object>} Created pending upgrade
     */
    async createPendingUpgrade(playerUuid, walletAddress, beaconKey, contractAddress, paymentAmount, expiresInMinutes = 60) {
        const expiresAt = new Date(Date.now() + expiresInMinutes * 60 * 1000);

        // Clean up any old 'cancelled' records for this wallet to avoid constraint violation
        await this.query(
            `DELETE FROM pending_upgrades WHERE wallet_address = $1 AND status = 'cancelled'`,
            [walletAddress]
        );

        // Cancel any existing pending upgrades for this wallet
        await this.query(
            `UPDATE pending_upgrades SET status = 'cancelled' WHERE wallet_address = $1 AND status = 'pending'`,
            [walletAddress]
        );

        const result = await this.query(
            `INSERT INTO pending_upgrades (player_uuid, wallet_address, beacon_key, contract_address, payment_amount, expires_at)
             VALUES ($1, $2, $3, $4, $5, $6)
             RETURNING *`,
            [playerUuid, walletAddress, beaconKey, contractAddress, paymentAmount, expiresAt]
        );

        return result[0];
    }

    /**
     * Get pending upgrade by wallet address
     */
    async getPendingUpgradeByWallet(walletAddress) {
        const result = await this.query(
            `SELECT * FROM pending_upgrades
             WHERE wallet_address = $1 AND status = 'pending'
             ORDER BY created_at DESC
             LIMIT 1`,
            [walletAddress]
        );
        return result[0] || null;
    }

    /**
     * Get pending upgrade by beacon key
     */
    async getPendingUpgradeByBeacon(beaconKey) {
        const result = await this.query(
            `SELECT * FROM pending_upgrades
             WHERE beacon_key = $1 AND status = 'pending'
             ORDER BY created_at DESC
             LIMIT 1`,
            [beaconKey]
        );
        return result[0] || null;
    }

    /**
     * Mark pending upgrade as paid
     */
    async markUpgradeAsPaid(id) {
        // First get the wallet address for this upgrade
        const upgrade = await this.query(
            `SELECT wallet_address FROM pending_upgrades WHERE id = $1`,
            [id]
        );

        if (!upgrade || upgrade.length === 0) {
            throw new Error('Upgrade not found');
        }

        const walletAddress = upgrade[0].wallet_address;

        // Delete ALL old records for this wallet (paid, completed, cancelled)
        // Keep only the current 'pending' one we're about to mark as 'paid'
        await this.query(
            `DELETE FROM pending_upgrades
             WHERE wallet_address = $1 AND id != $2`,
            [walletAddress, id]
        );

        // Now mark this upgrade as paid
        await this.query(
            `UPDATE pending_upgrades SET status = 'paid' WHERE id = $1`,
            [id]
        );
    }

    /**
     * Cancel pending upgrade
     */
    async cancelPendingUpgrade(walletAddress) {
        // First clean up any old 'cancelled' records for this wallet
        await this.query(
            `DELETE FROM pending_upgrades
             WHERE wallet_address = $1 AND status = 'cancelled'`,
            [walletAddress]
        );

        // Now cancel the current pending upgrade
        await this.query(
            `UPDATE pending_upgrades SET status = 'cancelled'
             WHERE wallet_address = $1 AND status = 'pending'`,
            [walletAddress]
        );
    }

    /**
     * Clean up expired pending upgrades
     */
    async cleanupExpiredUpgrades() {
        const result = await this.query(
            `UPDATE pending_upgrades
             SET status = 'expired'
             WHERE status = 'pending' AND expires_at < NOW()
             RETURNING *`
        );
        return result;
    }

    /**
     * Get all pending upgrades (for monitoring)
     */
    async getAllPendingUpgrades() {
        return await this.query(
            `SELECT * FROM pending_upgrades
             WHERE status = 'pending'
             ORDER BY created_at DESC`
        );
    }

    async close() {
        if (this.pool) {
            if (this.type === 'mysql') {
                await this.pool.end();
            } else if (this.type === 'postgres') {
                await this.pool.end();
            }
            logger.info('Database connection closed');
        }
    }
}

// Singleton instance
const db = new DatabaseService();

module.exports = db;

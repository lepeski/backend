const { MerkleTree } = require('merkletreejs');
const { ethers } = require('ethers');
const fs = require('fs');
const path = require('path');
const config = require('../config/config');
const logger = require('../utils/logger');

class MerkleService {
    constructor() {
        this.tree = null;
        this.leaves = [];
        this.root = null;
    }

    /**
     * Build Merkle tree from array of crystals (POSSESSION-BASED)
     * @param {Array<{crystalId: string}>} crystals - Array of crystal objects
     * @returns {string} Merkle root
     *
     * SECURITY: Possession-based ownership model
     * - Leaf = keccak256(crystalId) only (NO owner address)
     * - Enables PvP theft: whoever holds crystal can redeem
     * - Front-running prevented by backend possession verification
     * - Backend checks inventory before providing proof
     * - Crystal removed from inventory before transaction
     */
    buildTree(crystals) {
        try {
            logger.info(`Building Merkle tree with ${crystals.length} crystals (possession-based)`);

            // Store leaves WITHOUT ownership
            this.leaves = crystals.map(crystal => {
                const crystalId = crystal.crystalId || crystal.id;

                if (!crystalId) {
                    throw new Error('Crystal must have crystalId');
                }

                // Create leaf: DOUBLE HASH to match contract expectation
                // Contract does: keccak256(abi.encodePacked(crystalId)) where crystalId is already hashed
                // Step 1: Hash UUID string to bytes32
                const crystalIdHash = ethers.solidityPackedKeccak256(
                    ['string'],
                    [crystalId]
                );

                // Step 2: Hash it again (contract expects this)
                const leaf = ethers.keccak256(
                    ethers.solidityPacked(['bytes32'], [crystalIdHash])
                );

                // Remove 0x prefix for buffer
                const cleanLeaf = leaf.startsWith('0x') ? leaf.slice(2) : leaf;
                return Buffer.from(cleanLeaf, 'hex');
            });

            // Build tree using keccak256
            this.tree = new MerkleTree(this.leaves, ethers.keccak256, {
                sortPairs: true,
                hashLeaves: false // Leaves are already hashed
            });

            this.root = this.tree.getHexRoot();

            logger.info(`Merkle tree built (possession-based). Root: ${this.root}`);
            return this.root;
        } catch (error) {
            logger.logError(error, { context: 'Building Merkle tree' });
            throw error;
        }
    }

    /**
     * DEPRECATED: Old method without ownership (for backward compatibility)
     * @deprecated Use buildTree(crystals) with ownership instead
     */
    buildTreeLegacy(crystalIds) {
        try {
            logger.warn('Using legacy Merkle tree without ownership - INSECURE!');
            logger.info(`Building legacy Merkle tree with ${crystalIds.length} crystals`);

            this.leaves = crystalIds.map(id => {
                const cleanId = id.startsWith('0x') ? id.slice(2) : id;
                return Buffer.from(cleanId, 'hex');
            });

            this.tree = new MerkleTree(this.leaves, ethers.keccak256, {
                sortPairs: true,
                hashLeaves: false
            });

            this.root = this.tree.getHexRoot();

            logger.info(`Legacy Merkle tree built. Root: ${this.root}`);
            return this.root;
        } catch (error) {
            logger.logError(error, { context: 'Building legacy Merkle tree' });
            throw error;
        }
    }

    /**
     * Get Merkle proof for a crystal (POSSESSION-BASED)
     * @param {string} crystalId - Crystal ID (bytes32)
     * @returns {string[]} Array of proof hashes
     *
     * SECURITY: Possession-based - no owner in proof
     * Frontend-running prevented by backend possession verification
     */
    getProof(crystalId) {
        try {
            if (!this.tree) {
                throw new Error('Merkle tree not built yet');
            }

            // Create leaf: DOUBLE HASH to match contract expectation
            // Step 1: Hash UUID string to bytes32
            const crystalIdHash = ethers.solidityPackedKeccak256(
                ['string'],
                [crystalId]
            );

            // Step 2: Hash it again (contract expects this)
            const leaf = ethers.keccak256(
                ethers.solidityPacked(['bytes32'], [crystalIdHash])
            );

            const cleanLeaf = leaf.startsWith('0x') ? leaf.slice(2) : leaf;
            const leafBuffer = Buffer.from(cleanLeaf, 'hex');

            const proof = this.tree.getHexProof(leafBuffer);

            logger.info(`Generated proof for crystal ${crystalId} (possession-based)`, {
                proofLength: proof.length
            });

            return proof;
        } catch (error) {
            logger.logError(error, { context: 'Generating Merkle proof', crystalId });
            throw error;
        }
    }

    /**
     * DEPRECATED: Get proof without ownership (legacy)
     * @deprecated Use getProof(crystalId, ownerAddress) instead
     */
    getProofLegacy(crystalId) {
        try {
            logger.warn('Using legacy getProof without ownership - INSECURE!');
            if (!this.tree) {
                throw new Error('Merkle tree not built yet');
            }

            const cleanId = crystalId.startsWith('0x') ? crystalId.slice(2) : crystalId;
            const leaf = Buffer.from(cleanId, 'hex');

            const proof = this.tree.getHexProof(leaf);

            logger.info(`Generated legacy proof for crystal ${crystalId}`, {
                proofLength: proof.length
            });

            return proof;
        } catch (error) {
            logger.logError(error, { context: 'Generating legacy Merkle proof', crystalId });
            throw error;
        }
    }

    /**
     * Verify a Merkle proof
     * @param {string} crystalId - Crystal ID
     * @param {string[]} proof - Proof array
     * @param {string} root - Merkle root (optional, uses current root if not provided)
     * @returns {boolean} True if proof is valid
     */
    verifyProof(crystalId, proof, root = null) {
        try {
            const cleanId = crystalId.startsWith('0x') ? crystalId.slice(2) : crystalId;
            const leaf = Buffer.from(cleanId, 'hex');
            const rootToCheck = root || this.root;

            const isValid = this.tree.verify(proof, leaf, rootToCheck);

            logger.info(`Proof verification for ${crystalId}: ${isValid}`);
            return isValid;
        } catch (error) {
            logger.logError(error, { context: 'Verifying Merkle proof', crystalId });
            return false;
        }
    }

    /**
     * Get current Merkle root
     * @returns {string} Merkle root
     */
    getRoot() {
        if (!this.root) {
            throw new Error('Merkle tree not built yet');
        }
        return this.root;
    }

    /**
     * Save Merkle tree to file
     * @param {string} filePath - Optional custom file path
     */
    saveToFile(filePath = null) {
        try {
            const file = filePath || config.merkleTree.file;
            const dir = path.dirname(file);

            // Create directory if it doesn't exist
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }

            const data = {
                root: this.root,
                leaves: this.leaves.map(l => '0x' + l.toString('hex')),
                tree: this.tree.getHexLayers(),
                timestamp: new Date().toISOString(),
                totalLeaves: this.leaves.length
            };

            fs.writeFileSync(file, JSON.stringify(data, null, 2));

            logger.info(`Merkle tree saved to ${file}`, {
                root: this.root,
                leaves: this.leaves.length
            });
        } catch (error) {
            logger.logError(error, { context: 'Saving Merkle tree' });
            throw error;
        }
    }

    /**
     * Load Merkle tree from file
     * @param {string} filePath - Optional custom file path
     * @returns {boolean} True if loaded successfully
     */
    loadFromFile(filePath = null) {
        try {
            const file = filePath || config.merkleTree.file;

            if (!fs.existsSync(file)) {
                logger.warn(`Merkle tree file not found: ${file}`);
                return false;
            }

            const data = JSON.parse(fs.readFileSync(file, 'utf8'));

            this.root = data.root;
            this.leaves = data.leaves.map(l => {
                const cleanId = l.startsWith('0x') ? l.slice(2) : l;
                return Buffer.from(cleanId, 'hex');
            });

            // Rebuild tree from leaves
            this.tree = new MerkleTree(this.leaves, ethers.keccak256, {
                sortPairs: true,
                hashLeaves: false
            });

            logger.info(`Merkle tree loaded from ${file}`, {
                root: this.root,
                leaves: this.leaves.length,
                timestamp: data.timestamp
            });

            return true;
        } catch (error) {
            logger.logError(error, { context: 'Loading Merkle tree' });
            return false;
        }
    }

    /**
     * Get all leaves (crystal IDs) in the tree
     * @returns {string[]} Array of crystal IDs
     */
    getLeaves() {
        return this.leaves.map(l => '0x' + l.toString('hex'));
    }

    /**
     * Check if crystal is in tree
     * @param {string} crystalId - Crystal ID
     * @returns {boolean} True if crystal is in tree
     */
    contains(crystalId) {
        const cleanId = crystalId.startsWith('0x') ? crystalId.slice(2) : crystalId;
        const leaf = Buffer.from(cleanId, 'hex');
        return this.leaves.some(l => l.equals(leaf));
    }

    /**
     * Get tree statistics
     * @returns {object} Tree stats
     */
    getStats() {
        if (!this.tree) {
            return { built: false };
        }

        return {
            built: true,
            root: this.root,
            totalLeaves: this.leaves.length,
            treeDepth: this.tree.getDepth(),
            layerCount: this.tree.getLayers().length
        };
    }
}

// Singleton instance
const merkleService = new MerkleService();

module.exports = merkleService;

const { ethers } = require('ethers');
const config = require('../config/config');
const logger = require('../utils/logger');
const contractService = require('./contractService');

class GasService {
    constructor() {
        this.lastGasCheck = null;
        this.cacheTimeout = 30000; // 30 seconds cache
    }

    /**
     * Check if gas price is within acceptable threshold (9% rule)
     * @returns {Object} Gas check results
     */
    async checkGasThreshold() {
        try {
            // Return cached result if recent enough
            if (this.lastGasCheck && (Date.now() - this.lastGasCheck.timestamp) < this.cacheTimeout) {
                return this.lastGasCheck.data;
            }

            // Get current gas price
            const { gasPrice, gasPriceGwei } = await contractService.getGasPrice();
            const gasPriceBigInt = BigInt(gasPrice);

            // Get current tax rates from contract
            const taxRates = await contractService.getTaxRates();
            const userBPS = taxRates.user * 100; // Convert back to basis points

            // Calculate user payout in USD
            const CRYSTAL_VALUE = 9.0; // pDAI
            const userPayout = (CRYSTAL_VALUE * userBPS) / 10000;
            const userPayoutUSD = userPayout * config.prices.pDAI;

            // Calculate gas cost in PLS and USD
            const estimatedGas = BigInt(config.gas.estimatedGas);
            const gasCostPLS = (gasPriceBigInt * estimatedGas) / BigInt(1e18);
            const gasCostPLSFloat = parseFloat(ethers.formatEther(gasPriceBigInt * estimatedGas));
            const gasCostUSD = gasCostPLSFloat * config.prices.PLS;

            // Calculate 9% threshold
            const threshold = userPayoutUSD * (config.gas.maxPercentage / 100);

            // Determine if should reject
            const exceedsThreshold = gasCostUSD > threshold;
            const percentOfValue = (gasCostUSD / userPayoutUSD) * 100;

            const result = {
                gasPriceGwei: parseFloat(gasPriceGwei),
                gasCostUSD: gasCostUSD,
                userPayoutUSD: userPayoutUSD,
                threshold: threshold,
                exceedsThreshold: exceedsThreshold,
                shouldReject: exceedsThreshold,
                percentOfValue: percentOfValue.toFixed(2),
                maxPercentage: config.gas.maxPercentage,
                timestamp: Date.now()
            };

            // Cache result
            this.lastGasCheck = {
                timestamp: Date.now(),
                data: result
            };

            logger.info(`Gas check: ${gasPriceGwei} Gwei (${percentOfValue.toFixed(2)}% of value)`, {
                acceptable: !exceedsThreshold
            });

            return result;

        } catch (error) {
            logger.logError(error, { context: 'Gas threshold check' });
            throw error;
        }
    }

    /**
     * Get gas statistics
     */
    async getGasStats() {
        const gasCheck = await this.checkGasThreshold();

        return {
            current: {
                gasPrice: gasCheck.gasPriceGwei,
                gasCostUSD: gasCheck.gasCostUSD,
                percentOfValue: gasCheck.percentOfValue
            },
            threshold: {
                maxPercentage: gasCheck.maxPercentage,
                thresholdUSD: gasCheck.threshold,
                acceptable: !gasCheck.shouldReject
            },
            user: {
                payoutUSD: gasCheck.userPayoutUSD
            },
            recommendation: gasCheck.shouldReject
                ? 'Gas too high - Queue for later'
                : 'Gas acceptable - Process now'
        };
    }

    /**
     * Calculate max acceptable gas price
     */
    async getMaxAcceptableGas() {
        const taxRates = await contractService.getTaxRates();
        const userBPS = taxRates.user * 100;

        const CRYSTAL_VALUE = 9.0;
        const userPayout = (CRYSTAL_VALUE * userBPS) / 10000;
        const userPayoutUSD = userPayout * config.prices.pDAI;

        const threshold = userPayoutUSD * (config.gas.maxPercentage / 100);
        const maxGasCostPLS = threshold / config.prices.PLS;

        // Calculate max gas price in Gwei
        const maxGasPriceWei = (maxGasCostPLS * 1e18) / config.gas.estimatedGas;
        const maxGasPriceGwei = maxGasPriceWei / 1e9;

        return {
            maxGasPriceGwei: maxGasPriceGwei.toFixed(2),
            thresholdUSD: threshold,
            userPayoutUSD: userPayoutUSD
        };
    }

    /**
     * Clear cache (force fresh check)
     */
    clearCache() {
        this.lastGasCheck = null;
    }
}

// Singleton instance
const gasService = new GasService();

module.exports = gasService;

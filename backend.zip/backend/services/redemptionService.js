const db = require('./databaseService');
const merkleService = require('./merkleService');
const contractService = require('./contractService');
const pluginService = require('./pluginService');
const logger = require('../utils/logger');
const { ethers } = require('ethers');

/**
 * Helper function to convert crystal UUID to bytes32 format
 * Uses solidityPackedKeccak256 to match the Merkle tree leaf generation
 * CRITICAL: Must match merkleService.js line 41-44
 */
function crystalUuidToBytes32(uuid) {
    return ethers.solidityPackedKeccak256(['string'], [uuid]);
}

/**
 * Helper function to convert beacon UUID to bytes32 format
 * Uses keccak256(abi.encode(string)) to match beacon registration
 * CRITICAL: Must match beacons.js generateBeaconId function
 */
function beaconUuidToBytes32(uuid) {
    return ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(['string'], [uuid]));
}

/**
 * RedemptionService - Handles synchronous, real-time crystal redemptions
 *
 * Flow:
 * 1. Verify player has linked wallet
 * 2. Verify crystal exists and status
 * 3. Verify beacon is active
 * 4. Check if player is online
 * 5. Verify player has crystal in inventory
 * 6. Lock crystal (make undroppable, visual indicator)
 * 7. Mark crystal as REDEEMING in database
 * 8. Generate Merkle proof
 * 9. Get player's wallet address
 * 10. Submit transaction to contract and wait for confirmation
 * 11. Remove crystal from inventory
 * 12. Mark crystal as REDEEMED
 * 13. Log successful redemption and return transaction hash
 *
 * On Error: Rollback (unlock crystal, mark as HELD, return to player)
 */
class RedemptionService {
    /**
     * Process a crystal redemption synchronously
     * @param {string} userId - Minecraft player UUID
     * @param {string} crystalId - Crystal UUID
     * @param {string} beaconId - Beacon ID where redemption occurs
     * @param {string} ipAddress - Request IP for audit logging
     * @returns {Promise<object>} { success, txHash, error }
     */
    async processRedemption(userId, crystalId, beaconId, ipAddress = null) {
        const startTime = Date.now();
        let rollbackRequired = false;

        try {
            logger.info(`Starting redemption: user=${userId}, crystal=${crystalId}, beacon=${beaconId}`);

            // Step 1: Verify player has linked wallet
            const wallet = await db.getPlayerWallet(userId);
            if (!wallet) {
                throw new Error('No wallet linked. Use /linkwallet <address> to link your Ethereum wallet first.');
            }

            // Step 2: Verify crystal exists and get details
            const crystal = await db.getCrystal(crystalId);
            if (!crystal) {
                throw new Error('Crystal not found in database');
            }

            // Step 3: Check crystal status
            if (crystal.status === 'REDEEMED') {
                throw new Error('Crystal already redeemed');
            }

            if (crystal.status === 'REDEEMING') {
                throw new Error('Crystal is already being redeemed');
            }

            if (crystal.status === 'LOST') {
                throw new Error('Crystal is lost and cannot be redeemed');
            }

            // Step 4: Verify beacon exists and is active
            // NOTE: Beacon validation is handled by the plugin (claims.json)
            // Plugin already verified player is at upgraded beacon with public redemption
            // Skipping database check since beacons are not synced to PostgreSQL
            // const beacon = await db.getBeacon(beaconId);
            // if (!beacon) {
            //     throw new Error('Beacon not found');
            // }
            // if (!beacon.active) {
            //     throw new Error('Beacon is not active');
            // }

            // Step 5: Check if player is online
            const isOnline = await pluginService.isPlayerOnline(userId);
            if (!isOnline) {
                throw new Error('Player is not online');
            }

            // Step 5: Verify player has crystal in inventory (CRITICAL)
            logger.info(`Verifying inventory for user ${userId}, crystal ${crystalId}`);
            const hasCrystal = await pluginService.verifyPlayerInventory(userId, crystalId);

            if (!hasCrystal) {
                await db.logAuditEvent({
                    event_type: 'REDEMPTION_FAILED',
                    user_id: userId,
                    crystal_id: crystalId,
                    beacon_id: beaconId,
                    success: false,
                    error: 'Player does not have crystal in inventory',
                    ip_address: ipAddress,
                    metadata: { step: 'inventory_verification' }
                });

                return {
                    success: false,
                    error: 'You do not have this crystal in your inventory',
                    code: 'NO_POSSESSION'
                };
            }

            // Step 6: Lock crystal in inventory (make undroppable, add visual indicator)
            logger.info(`Locking crystal ${crystalId} for user ${userId}`);
            const locked = await pluginService.lockCrystal(userId, crystalId);

            if (!locked) {
                await db.logAuditEvent({
                    event_type: 'REDEMPTION_FAILED',
                    user_id: userId,
                    crystal_id: crystalId,
                    beacon_id: beaconId,
                    success: false,
                    error: 'Failed to lock crystal',
                    ip_address: ipAddress,
                    metadata: { step: 'lock_crystal' }
                });

                return {
                    success: false,
                    error: 'Failed to lock crystal. Please try again.',
                    code: 'LOCK_FAILED'
                };
            }

            rollbackRequired = true; // From this point, we need to rollback on error

            // Step 7: Mark crystal as REDEEMING in database
            logger.info(`Marking crystal ${crystalId} as REDEEMING`);
            await db.updateCrystalStatus(crystalId, 'REDEEMING', {
                userId,
                beaconId,
                requestedAt: Date.now(),
                ip: ipAddress
            });

            // Step 8: Generate Merkle proof
            logger.info(`Generating Merkle proof for crystal ${crystalId}`);
            const proof = merkleService.getProof(crystalId);

            if (!proof || proof.length === 0) {
                throw new Error('Failed to generate Merkle proof - crystal not in tree');
            }

            // Step 9: Get player's wallet address
            const playerWallet = await db.getPlayerWallet(userId);
            if (!playerWallet || !playerWallet.wallet_address) {
                throw new Error('Player wallet not linked. Use /linkwallet first.');
            }

            // Step 10: Submit transaction to contract
            logger.info(`Submitting redemption transaction to contract: crystal=${crystalId}, beacon=${beaconId}`);

            // Convert UUIDs to bytes32 format for contract
            // NOTE: Crystals and beacons use different hashing methods!
            const crystalIdBytes32 = crystalUuidToBytes32(crystalId);
            const beaconIdBytes32 = beaconUuidToBytes32(beaconId);

            logger.info(`Converted to bytes32: crystal=${crystalIdBytes32}, beacon=${beaconIdBytes32}`);

            const txResult = await contractService.redeemCrystal(
                crystalIdBytes32,
                playerWallet.wallet_address, // ownerAddress
                beaconIdBytes32,
                playerWallet.wallet_address, // payoutAddress
                proof
            );

            if (!txResult || !txResult.txHash) {
                throw new Error('Transaction submission failed: ' + (txResult?.error || 'Unknown error'));
            }

            logger.info(`Transaction confirmed: ${txResult.txHash}`);

            // Step 11: Remove crystal from inventory (AFTER confirmation)
            logger.info(`Removing crystal ${crystalId} from inventory`);
            const removed = await pluginService.removeFromInventory(userId, crystalId);

            if (!removed) {
                logger.logError(new Error('Failed to remove crystal after successful redemption'), {
                    userId,
                    crystalId,
                    txHash: txResult.txHash,
                    note: 'Transaction succeeded but crystal removal failed - needs manual cleanup'
                });
                // Don't fail the redemption - transaction already succeeded
            }

            // Step 12: Mark crystal as REDEEMED in database
            await db.updateCrystalStatus(crystalId, 'REDEEMED', {
                userId,
                beaconId,
                txHash: txResult.txHash,
                redeemedAt: Date.now(),
                duration: Date.now() - startTime
            });

            // Also update old redeemed flag for backwards compatibility
            await db.markCrystalRedeemed(crystalId, txResult.txHash);

            // Step 13: Log successful redemption
            await db.logAuditEvent({
                event_type: 'REDEMPTION_SUCCESS',
                user_id: userId,
                crystal_id: crystalId,
                beacon_id: beaconId,
                success: true,
                ip_address: ipAddress,
                metadata: {
                    txHash: txResult.txHash,
                    duration: Date.now() - startTime,
                    walletAddress: playerWallet.wallet_address
                }
            });

            logger.info(`Redemption completed successfully: ${txResult.txHash} (${Date.now() - startTime}ms)`);

            return {
                success: true,
                txHash: txResult.txHash,
                duration: Date.now() - startTime,
                explorerUrl: `https://scan.pulsechain.com/tx/${txResult.txHash}`
            };

        } catch (error) {
            logger.logError(error, {
                context: 'Process redemption',
                userId,
                crystalId,
                beaconId,
                duration: Date.now() - startTime
            });

            // Rollback if needed
            if (rollbackRequired) {
                await this.rollback(userId, crystalId, error.message);
            }

            // Log failed redemption
            await db.logAuditEvent({
                event_type: 'REDEMPTION_FAILED',
                user_id: userId,
                crystal_id: crystalId,
                beacon_id: beaconId,
                success: false,
                error: error.message,
                ip_address: ipAddress,
                metadata: {
                    duration: Date.now() - startTime,
                    rollbackRequired
                }
            });

            return {
                success: false,
                error: error.message,
                code: this.getErrorCode(error.message)
            };
        }
    }

    /**
     * Rollback a failed redemption
     * @private
     */
    async rollback(userId, crystalId, reason) {
        logger.info(`Rolling back redemption for crystal ${crystalId}: ${reason}`);

        try {
            // Step 1: Unlock crystal (remove undroppable flag, restore original state)
            const unlocked = await pluginService.unlockCrystal(userId, crystalId);

            if (!unlocked) {
                logger.logError(new Error('Failed to unlock crystal during rollback'), {
                    userId,
                    crystalId,
                    reason
                });
            }

            // Step 2: Mark crystal as HELD in database
            await db.updateCrystalStatus(crystalId, 'HELD', {
                userId,
                rolledBackAt: Date.now(),
                rollbackReason: reason
            });

            // Step 3: Log rollback
            await db.logAuditEvent({
                event_type: 'REDEMPTION_ROLLBACK',
                user_id: userId,
                crystal_id: crystalId,
                success: true,
                metadata: { reason }
            });

            logger.info(`Rollback completed for crystal ${crystalId}`);

        } catch (rollbackError) {
            logger.logError(rollbackError, {
                context: 'Redemption rollback failed',
                userId,
                crystalId,
                originalError: reason,
                note: 'CRITICAL: Crystal may be in inconsistent state - needs manual intervention'
            });

            // Mark crystal as LOST if rollback fails
            try {
                await db.updateCrystalStatus(crystalId, 'LOST', {
                    userId,
                    reason: 'Rollback failed after redemption error',
                    originalError: reason,
                    rollbackError: rollbackError.message,
                    requiresManualIntervention: true
                });
            } catch (err) {
                logger.logError(err, {
                    context: 'Failed to mark crystal as LOST after rollback failure'
                });
            }
        }
    }

    /**
     * Get error code from error message
     * @private
     */
    getErrorCode(message) {
        if (message.includes('not found')) return 'NOT_FOUND';
        if (message.includes('already redeemed')) return 'ALREADY_REDEEMED';
        if (message.includes('already being redeemed')) return 'IN_PROGRESS';
        if (message.includes('not active')) return 'BEACON_INACTIVE';
        if (message.includes('not online')) return 'PLAYER_OFFLINE';
        if (message.includes('inventory')) return 'NO_POSSESSION';
        if (message.includes('wallet not linked')) return 'NO_WALLET';
        if (message.includes('Merkle proof')) return 'PROOF_FAILED';
        if (message.includes('Transaction failed')) return 'TX_FAILED';
        return 'UNKNOWN';
    }

    /**
     * Get redemption status for a crystal
     */
    async getRedemptionStatus(crystalId) {
        try {
            const crystal = await db.getCrystal(crystalId);

            if (!crystal) {
                return {
                    exists: false,
                    error: 'Crystal not found'
                };
            }

            return {
                exists: true,
                crystalId: crystal.id,
                status: crystal.status,
                redeemed: crystal.redeemed,
                txHash: crystal.tx_hash,
                redeemedAt: crystal.redeemed_at,
                metadata: crystal.metadata ? JSON.parse(crystal.metadata) : {}
            };

        } catch (error) {
            logger.logError(error, { context: 'Get redemption status', crystalId });
            return {
                exists: false,
                error: error.message
            };
        }
    }

    /**
     * Cleanup stuck REDEEMING crystals (for cron job)
     * @param {number} maxAgeMinutes - Max age before considering stuck
     */
    async cleanupStuckRedemptions(maxAgeMinutes = 30) {
        try {
            logger.info(`Cleaning up stuck REDEEMING crystals (older than ${maxAgeMinutes} minutes)`);

            const stuckCrystals = await db.getStuckRedeemingCrystals(maxAgeMinutes);

            if (stuckCrystals.length === 0) {
                logger.info('No stuck crystals found');
                return { cleaned: 0 };
            }

            logger.info(`Found ${stuckCrystals.length} stuck crystals`);

            for (const crystal of stuckCrystals) {
                try {
                    // Try to unlock crystal if player is still online
                    const metadata = crystal.metadata ? JSON.parse(crystal.metadata) : {};
                    const userId = metadata.userId;

                    if (userId) {
                        const isOnline = await pluginService.isPlayerOnline(userId);
                        if (isOnline) {
                            await pluginService.unlockCrystal(userId, crystal.id);
                        }
                    }

                    // Mark as HELD (or LOST if too old)
                    const ageHours = (Date.now() - new Date(crystal.updated_at).getTime()) / (1000 * 60 * 60);
                    const newStatus = ageHours > 24 ? 'LOST' : 'HELD';

                    await db.updateCrystalStatus(crystal.id, newStatus, {
                        cleanedUpAt: Date.now(),
                        reason: `Stuck in REDEEMING for ${Math.floor(ageHours)} hours`,
                        originalMetadata: metadata
                    });

                    logger.info(`Cleaned up stuck crystal ${crystal.id}: ${newStatus}`);

                } catch (error) {
                    logger.logError(error, {
                        context: 'Cleanup stuck crystal',
                        crystalId: crystal.id
                    });
                }
            }

            return { cleaned: stuckCrystals.length };

        } catch (error) {
            logger.logError(error, { context: 'Cleanup stuck redemptions' });
            throw error;
        }
    }
}

// Singleton instance
const redemptionService = new RedemptionService();

module.exports = redemptionService;

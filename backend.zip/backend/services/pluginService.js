const axios = require('axios');
const config = require('../config/config');
const logger = require('../utils/logger');

/**
 * PluginService - Handles communication with Minecraft plugin
 * Used for inventory verification and crystal item management
 */
class PluginService {
    constructor() {
        this.pluginApiUrl = config.pluginApi || 'http://localhost:8080';
        this.apiKey = config.pluginApiKey;
        this.timeout = 5000; // 5 second timeout
    }

    /**
     * Make authenticated request to plugin API
     * @private
     */
    async makeRequest(endpoint, method = 'POST', data = {}) {
        try {
            const response = await axios({
                method,
                url: `${this.pluginApiUrl}${endpoint}`,
                data,
                headers: {
                    'X-API-Key': this.apiKey,
                    'Content-Type': 'application/json'
                },
                timeout: this.timeout
            });

            return response.data;
        } catch (error) {
            logger.logError(error, {
                context: 'Plugin API request',
                endpoint,
                method,
                data
            });

            // Return safe error response
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Verify player has crystal in their inventory
     * @param {string} userId - Minecraft player UUID
     * @param {string} crystalId - Crystal UUID
     * @returns {Promise<boolean>} True if player has crystal
     */
    async verifyPlayerInventory(userId, crystalId) {
        try {
            logger.info(`Verifying inventory for player ${userId}, crystal ${crystalId}`);

            const response = await this.makeRequest('/api/inventory/check', 'POST', {
                userId,
                crystalId
            });

            if (!response.success) {
                logger.logSecurity('Inventory verification failed', {
                    userId,
                    crystalId,
                    reason: response.error
                });
                return false;
            }

            const hasCrystal = response.hasCrystal === true;

            logger.info(`Inventory verification result: ${hasCrystal}`, {
                userId,
                crystalId
            });

            return hasCrystal;

        } catch (error) {
            logger.logError(error, {
                context: 'Verify player inventory',
                userId,
                crystalId
            });

            // Fail closed - deny if verification fails
            return false;
        }
    }

    /**
     * Lock crystal item (make undroppable, add glow effect, mark as "Redeeming...")
     * @param {string} userId - Minecraft player UUID
     * @param {string} crystalId - Crystal UUID
     * @returns {Promise<boolean>} True if locked successfully
     */
    async lockCrystal(userId, crystalId) {
        try {
            logger.info(`Locking crystal ${crystalId} for player ${userId}`);

            const response = await this.makeRequest('/api/inventory/lock', 'POST', {
                userId,
                crystalId
            });

            if (!response.success) {
                logger.logError(new Error('Failed to lock crystal'), {
                    userId,
                    crystalId,
                    reason: response.error
                });
                return false;
            }

            logger.info(`Crystal ${crystalId} locked successfully`, { userId });
            return true;

        } catch (error) {
            logger.logError(error, {
                context: 'Lock crystal',
                userId,
                crystalId
            });
            return false;
        }
    }

    /**
     * Unlock crystal item (rollback - make droppable again, remove glow)
     * @param {string} userId - Minecraft player UUID
     * @param {string} crystalId - Crystal UUID
     * @returns {Promise<boolean>} True if unlocked successfully
     */
    async unlockCrystal(userId, crystalId) {
        try {
            logger.info(`Unlocking crystal ${crystalId} for player ${userId}`);

            const response = await this.makeRequest('/api/inventory/unlock', 'POST', {
                userId,
                crystalId
            });

            if (!response.success) {
                logger.logError(new Error('Failed to unlock crystal'), {
                    userId,
                    crystalId,
                    reason: response.error
                });
                return false;
            }

            logger.info(`Crystal ${crystalId} unlocked successfully`, { userId });
            return true;

        } catch (error) {
            logger.logError(error, {
                context: 'Unlock crystal',
                userId,
                crystalId
            });
            return false;
        }
    }

    /**
     * Remove crystal from player inventory (after successful redemption)
     * @param {string} userId - Minecraft player UUID
     * @param {string} crystalId - Crystal UUID
     * @returns {Promise<boolean>} True if removed successfully
     */
    async removeFromInventory(userId, crystalId) {
        try {
            logger.info(`Removing crystal ${crystalId} from player ${userId} inventory`);

            const response = await this.makeRequest('/api/inventory/remove', 'POST', {
                userId,
                crystalId
            });

            if (!response.success) {
                logger.logError(new Error('Failed to remove crystal from inventory'), {
                    userId,
                    crystalId,
                    reason: response.error
                });
                return false;
            }

            logger.info(`Crystal ${crystalId} removed from inventory`, { userId });
            return true;

        } catch (error) {
            logger.logError(error, {
                context: 'Remove from inventory',
                userId,
                crystalId
            });
            return false;
        }
    }

    /**
     * Return crystal to player inventory (rollback after failed transaction)
     * @param {string} userId - Minecraft player UUID
     * @param {string} crystalId - Crystal UUID
     * @returns {Promise<boolean>} True if returned successfully
     */
    async returnToInventory(userId, crystalId) {
        try {
            logger.info(`Returning crystal ${crystalId} to player ${userId} inventory`);

            const response = await this.makeRequest('/api/inventory/return', 'POST', {
                userId,
                crystalId
            });

            if (!response.success) {
                logger.logError(new Error('Failed to return crystal to inventory'), {
                    userId,
                    crystalId,
                    reason: response.error
                });
                return false;
            }

            logger.info(`Crystal ${crystalId} returned to inventory`, { userId });
            return true;

        } catch (error) {
            logger.logError(error, {
                context: 'Return to inventory',
                userId,
                crystalId
            });
            return false;
        }
    }

    /**
     * Check if player is online
     * @param {string} userId - Minecraft player UUID
     * @returns {Promise<boolean>} True if player is online
     */
    async isPlayerOnline(userId) {
        try {
            const response = await this.makeRequest('/api/player/online', 'POST', {
                userId
            });

            return response.success && response.online === true;

        } catch (error) {
            logger.logError(error, {
                context: 'Check player online',
                userId
            });
            return false;
        }
    }

    /**
     * Get player's wallet address from plugin
     * @param {string} userId - Minecraft player UUID
     * @returns {Promise<string|null>} Wallet address or null
     */
    async getPlayerWallet(userId) {
        try {
            const response = await this.makeRequest('/api/player/wallet', 'POST', {
                userId
            });

            if (response.success && response.walletAddress) {
                return response.walletAddress;
            }

            return null;

        } catch (error) {
            logger.logError(error, {
                context: 'Get player wallet',
                userId
            });
            return null;
        }
    }

    /**
     * Health check - verify plugin is responsive
     * @returns {Promise<boolean>} True if plugin is healthy
     */
    async healthCheck() {
        try {
            const response = await this.makeRequest('/api/health', 'GET');
            return response.success === true;
        } catch (error) {
            logger.logError(error, { context: 'Plugin health check' });
            return false;
        }
    }
}

// Singleton instance
const pluginService = new PluginService();

module.exports = pluginService;

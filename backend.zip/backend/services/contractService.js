const { ethers } = require('ethers');
const config = require('../config/config');
const logger = require('../utils/logger');

// Contract ABI (minimal, only functions we need)
const CRYSTAL_REDEMPTION_ABI = [
    "function redeemCrystal(bytes32 crystalId, address ownerAddress, bytes32 beaconId, address payoutAddress, bytes32[] calldata merkleProof) external",
    "function redeemCrystalForToken(bytes32 crystalId, address ownerAddress, bytes32 beaconId, address payoutAddress, address payoutToken, uint256 minAmountOut, bytes32[] calldata merkleProof) external",
    // View functions for debugging
    "function merkleRoot() external view returns (bytes32)",
    "function beacons(bytes32) external view returns (address owner, bool isActive, uint256 crystalsIssued)",
    "function redeemedCrystals(bytes32) external view returns (bool)",
    "function registerBeacon(bytes32 beaconId, address owner) external",
    "function registerBeaconsBatch(bytes32[] calldata beaconIds, address[] calldata owners) external",
    "function updateMerkleRoot(bytes32 newMerkleRoot) external",
    "function deactivateBeacon(bytes32 beaconId) external",
    "function updateBeaconOwner(bytes32 beaconId, address newOwner) external",
    "function isCrystalRedeemed(bytes32 crystalId) external view returns (bool)",
    "function isBeaconActive(bytes32 beaconId) external view returns (bool)",
    "function getBeaconOwner(bytes32 beaconId) external view returns (address)",
    "function getContractBalance() external view returns (uint256)",
    "function getTaxRates() external view returns (uint256, uint256, uint256)",
    "function calculatePayout() external view returns (uint256, uint256, uint256)",
    "function getCurrentMerkleRoot() external view returns (bytes32)",
    "function pauseRedemptions() external",
    "function unpauseRedemptions() external",
    "function nonces(address account) external view returns (uint256)",
    "function beaconRegistrationCost() external view returns (uint256)",
    "event CrystalRedeemed(bytes32 indexed crystalId, bytes32 indexed beaconId, address indexed payoutAddress, address payoutToken, address landownerAddress, uint256 userAmount, uint256 landownerTax, uint256 serverFee, uint256 timestamp)",
    "event BeaconRegistered(bytes32 indexed beaconId, address indexed owner, uint256 timestamp)"
];

class ContractService {
    constructor() {
        this.provider = null;
        this.wallet = null;
        this.contract = null;
        this.initialized = false;
    }

    /**
     * Initialize connection to blockchain and contract
     */
    async initialize() {
        try {
            // Create provider
            this.provider = new ethers.JsonRpcProvider(config.blockchain.rpcUrl);

            // Test connection
            const network = await this.provider.getNetwork();
            logger.info(`Connected to blockchain`, {
                chainId: network.chainId.toString(),
                name: network.name
            });

            // Create wallet
            this.wallet = new ethers.Wallet(config.serverWallet.privateKey, this.provider);
            logger.info(`Server wallet initialized: ${this.wallet.address}`);

            // Verify wallet address matches config
            if (this.wallet.address.toLowerCase() !== config.serverWallet.address.toLowerCase()) {
                throw new Error('Server wallet address mismatch');
            }

            // Initialize contract
            this.contract = new ethers.Contract(
                config.contracts.crystal,
                CRYSTAL_REDEMPTION_ABI,
                this.wallet
            );

            // Verify contract is deployed
            const code = await this.provider.getCode(config.contracts.crystal);
            if (code === '0x') {
                throw new Error('Contract not deployed at specified address');
            }

            this.initialized = true;
            logger.info(`Contract service initialized`, {
                contract: config.contracts.crystal
            });

        } catch (error) {
            logger.logError(error, { context: 'Contract service initialization' });
            throw error;
        }
    }

    /**
     * Check if service is ready
     */
    ensureInitialized() {
        if (!this.initialized) {
            throw new Error('Contract service not initialized');
        }
    }

    // ============ Redemption Functions ============

    /**
     * Redeem crystal for pDAI
     */
    async redeemCrystal(crystalId, ownerAddress, beaconId, payoutAddress, merkleProof) {
        this.ensureInitialized();

        try {
            logger.logContract('redeemCrystal', {
                crystalId,
                ownerAddress,
                beaconId,
                payoutAddress
            });

            const tx = await this.contract.redeemCrystal(
                crystalId,
                ownerAddress,
                beaconId,
                payoutAddress,
                merkleProof
            );

            logger.info(`Transaction sent: ${tx.hash}`);

            const receipt = await tx.wait();

            logger.logContract('redeemCrystal completed', {
                txHash: receipt.hash,
                gasUsed: receipt.gasUsed.toString(),
                status: receipt.status
            });

            return {
                success: true,
                txHash: receipt.hash,
                gasUsed: receipt.gasUsed.toString(),
                blockNumber: receipt.blockNumber
            };

        } catch (error) {
            logger.logError(error, {
                context: 'redeemCrystal',
                crystalId,
                beaconId
            });
            throw error;
        }
    }

    /**
     * Redeem crystal for specific token (multi-asset)
     */
    async redeemCrystalForToken(crystalId, ownerAddress, beaconId, payoutAddress, payoutToken, minAmountOut, merkleProof) {
        this.ensureInitialized();

        try {
            logger.logContract('redeemCrystalForToken', {
                crystalId,
                ownerAddress,
                beaconId,
                payoutAddress,
                payoutToken
            });

            const tx = await this.contract.redeemCrystalForToken(
                crystalId,
                ownerAddress,
                beaconId,
                payoutAddress,
                payoutToken,
                minAmountOut,
                merkleProof
            );

            logger.info(`Transaction sent: ${tx.hash}`);

            const receipt = await tx.wait();

            logger.logContract('redeemCrystalForToken completed', {
                txHash: receipt.hash,
                gasUsed: receipt.gasUsed.toString(),
                status: receipt.status
            });

            return {
                success: true,
                txHash: receipt.hash,
                gasUsed: receipt.gasUsed.toString(),
                blockNumber: receipt.blockNumber
            };

        } catch (error) {
            logger.logError(error, {
                context: 'redeemCrystalForToken',
                crystalId,
                payoutToken
            });
            throw error;
        }
    }

    // ============ Beacon Management ============

    /**
     * Register a single beacon
     */
    async registerBeacon(beaconId, ownerAddress) {
        this.ensureInitialized();

        try {
            logger.logContract('registerBeacon', {
                beaconId,
                ownerAddress
            });

            const tx = await this.contract.registerBeacon(beaconId, ownerAddress);
            const receipt = await tx.wait();

            logger.logContract('registerBeacon completed', {
                txHash: receipt.hash,
                beaconId
            });

            return {
                success: true,
                txHash: receipt.hash
            };

        } catch (error) {
            logger.logError(error, {
                context: 'registerBeacon',
                beaconId
            });
            throw error;
        }
    }

    /**
     * Register multiple beacons (batch)
     */
    async registerBeaconsBatch(beaconIds, ownerAddresses) {
        this.ensureInitialized();

        try {
            logger.logContract('registerBeaconsBatch', {
                count: beaconIds.length
            });

            const tx = await this.contract.registerBeaconsBatch(beaconIds, ownerAddresses);
            const receipt = await tx.wait();

            logger.logContract('registerBeaconsBatch completed', {
                txHash: receipt.hash,
                count: beaconIds.length
            });

            return {
                success: true,
                txHash: receipt.hash,
                count: beaconIds.length
            };

        } catch (error) {
            logger.logError(error, {
                context: 'registerBeaconsBatch',
                count: beaconIds.length
            });
            throw error;
        }
    }

    /**
     * Deactivate a beacon
     */
    async deactivateBeacon(beaconId) {
        this.ensureInitialized();

        try {
            const tx = await this.contract.deactivateBeacon(beaconId);
            const receipt = await tx.wait();

            logger.logContract('deactivateBeacon', {
                txHash: receipt.hash,
                beaconId
            });

            return {
                success: true,
                txHash: receipt.hash
            };

        } catch (error) {
            logger.logError(error, {
                context: 'deactivateBeacon',
                beaconId
            });
            throw error;
        }
    }

    /**
     * Update beacon owner
     */
    async updateBeaconOwner(beaconId, newOwner) {
        this.ensureInitialized();

        try {
            const tx = await this.contract.updateBeaconOwner(beaconId, newOwner);
            const receipt = await tx.wait();

            logger.logContract('updateBeaconOwner', {
                txHash: receipt.hash,
                beaconId,
                newOwner
            });

            return {
                success: true,
                txHash: receipt.hash
            };

        } catch (error) {
            logger.logError(error, {
                context: 'updateBeaconOwner',
                beaconId
            });
            throw error;
        }
    }

    // ============ Merkle Tree Functions ============

    /**
     * Update Merkle root on contract
     */
    async updateMerkleRoot(newRoot) {
        this.ensureInitialized();

        try {
            logger.logContract('updateMerkleRoot', {
                newRoot
            });

            const tx = await this.contract.updateMerkleRoot(newRoot);
            const receipt = await tx.wait();

            logger.logContract('updateMerkleRoot completed', {
                txHash: receipt.hash,
                newRoot
            });

            return {
                success: true,
                txHash: receipt.hash
            };

        } catch (error) {
            logger.logError(error, {
                context: 'updateMerkleRoot',
                newRoot
            });
            throw error;
        }
    }

    // ============ View Functions ============

    /**
     * Check if crystal is redeemed
     */
    async isCrystalRedeemed(crystalId) {
        this.ensureInitialized();
        return await this.contract.isCrystalRedeemed(crystalId);
    }

    /**
     * Check if beacon is active
     */
    async isBeaconActive(beaconId) {
        this.ensureInitialized();
        return await this.contract.isBeaconActive(beaconId);
    }

    /**
     * Get beacon owner
     */
    async getBeaconOwner(beaconId) {
        this.ensureInitialized();
        return await this.contract.getBeaconOwner(beaconId);
    }

    /**
     * Get account nonce for beacon registration
     */
    async getNonce(address) {
        this.ensureInitialized();
        const nonce = await this.contract.nonces(address);
        return Number(nonce);
    }

    /**
     * Get beacon registration cost
     */
    async getBeaconRegistrationCost() {
        this.ensureInitialized();
        const cost = await this.contract.beaconRegistrationCost();
        return cost;
    }

    /**
     * Get contract pDAI balance
     */
    async getContractBalance() {
        this.ensureInitialized();
        const balance = await this.contract.getContractBalance();
        return ethers.formatEther(balance);
    }

    /**
     * Get current tax rates
     */
    async getTaxRates() {
        this.ensureInitialized();
        const [userBPS, landownerBPS, serverBPS] = await this.contract.getTaxRates();
        return {
            user: Number(userBPS) / 100,
            landowner: Number(landownerBPS) / 100,
            server: Number(serverBPS) / 100
        };
    }

    /**
     * Calculate payout amounts
     */
    async calculatePayout() {
        this.ensureInitialized();
        const [userAmount, landownerTax, serverFee] = await this.contract.calculatePayout();
        return {
            userAmount: ethers.formatEther(userAmount),
            landownerTax: ethers.formatEther(landownerTax),
            serverFee: ethers.formatEther(serverFee)
        };
    }

    /**
     * Get current Merkle root from contract
     */
    async getCurrentMerkleRoot() {
        this.ensureInitialized();
        return await this.contract.getCurrentMerkleRoot();
    }

    // ============ Emergency Functions ============

    /**
     * Pause redemptions
     */
    async pauseRedemptions() {
        this.ensureInitialized();

        try {
            const tx = await this.contract.pauseRedemptions();
            const receipt = await tx.wait();

            logger.logContract('pauseRedemptions', {
                txHash: receipt.hash
            });

            return {
                success: true,
                txHash: receipt.hash
            };

        } catch (error) {
            logger.logError(error, { context: 'pauseRedemptions' });
            throw error;
        }
    }

    /**
     * Unpause redemptions
     */
    async unpauseRedemptions() {
        this.ensureInitialized();

        try {
            const tx = await this.contract.unpauseRedemptions();
            const receipt = await tx.wait();

            logger.logContract('unpauseRedemptions', {
                txHash: receipt.hash
            });

            return {
                success: true,
                txHash: receipt.hash
            };

        } catch (error) {
            logger.logError(error, { context: 'unpauseRedemptions' });
            throw error;
        }
    }

    // ============ Gas & Balance Functions ============

    /**
     * Get current gas price
     */
    async getGasPrice() {
        this.ensureInitialized();
        const feeData = await this.provider.getFeeData();
        const gasPriceGwei = parseFloat(ethers.formatUnits(feeData.gasPrice, 'gwei'));
        return {
            gasPrice: feeData.gasPrice.toString(),
            gasPriceGwei: gasPriceGwei.toFixed(2)
        };
    }

    /**
     * Get server wallet PLS balance
     */
    async getServerBalance() {
        this.ensureInitialized();
        const balance = await this.provider.getBalance(this.wallet.address);
        return ethers.formatEther(balance);
    }

    /**
     * Get network info
     */
    async getNetworkInfo() {
        this.ensureInitialized();
        const network = await this.provider.getNetwork();
        const blockNumber = await this.provider.getBlockNumber();
        return {
            chainId: network.chainId.toString(),
            name: network.name,
            blockNumber
        };
    }

    /**
     * Get server wallet for signing
     */
    get serverWallet() {
        this.ensureInitialized();
        return this.wallet;
    }
}

// Singleton instance
const contractService = new ContractService();

module.exports = contractService;

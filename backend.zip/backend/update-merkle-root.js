/**
 * Manual Merkle root update script
 * Use this when the on-chain root gets out of sync
 *
 * This script uses the update queue to ensure proper batching
 * and prevent concurrent transaction errors.
 */

const db = require('./services/databaseService');
const contractService = require('./services/contractService');
const merkleRootUpdateQueue = require('./services/merkleRootUpdateQueue');
const merkleService = require('./services/merkleService');
const logger = require('./utils/logger');

async function updateMerkleRoot() {
    try {
        logger.info('Starting manual Merkle root update...');

        // Initialize database
        logger.info('Connecting to database...');
        await db.connect();
        logger.info('Database connected');

        // Initialize contract service
        logger.info('Initializing contract service...');
        await contractService.initialize();
        logger.info('Contract service initialized');

        // Force immediate update via queue (bypasses debounce)
        logger.info('Triggering Merkle root update via queue...');
        await merkleRootUpdateQueue.forceUpdate();

        const stats = merkleService.getStats();

        logger.info('✅ Merkle root updated successfully!');
        logger.info(`Root: ${stats.root}`);
        logger.info(`Total crystals: ${stats.totalLeaves}`);

        process.exit(0);
    } catch (error) {
        logger.logError(error, { context: 'Manual Merkle root update' });
        process.exit(1);
    }
}

updateMerkleRoot();

-- Fix: Normalize all wallet addresses to lowercase for consistency
-- This prevents foreign key constraint violations

-- Update player_wallets to lowercase
UPDATE player_wallets
SET wallet_address = LOWER(wallet_address);

-- Update pending_upgrades to lowercase (if any exist)
UPDATE pending_upgrades
SET wallet_address = LOWER(wallet_address);

-- Add a trigger to ensure future inserts are lowercase (optional but recommended)
-- This ensures data consistency even if application code forgets to lowercase

CREATE OR REPLACE FUNCTION lowercase_wallet_address()
RETURNS TRIGGER AS $$
BEGIN
    NEW.wallet_address = LOWER(NEW.wallet_address);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for player_wallets
DROP TRIGGER IF EXISTS lowercase_wallet_on_insert_player_wallets ON player_wallets;
CREATE TRIGGER lowercase_wallet_on_insert_player_wallets
BEFORE INSERT OR UPDATE ON player_wallets
FOR EACH ROW
EXECUTE FUNCTION lowercase_wallet_address();

-- Trigger for pending_upgrades
DROP TRIGGER IF EXISTS lowercase_wallet_on_insert_pending_upgrades ON pending_upgrades;
CREATE TRIGGER lowercase_wallet_on_insert_pending_upgrades
BEFORE INSERT OR UPDATE ON pending_upgrades
FOR EACH ROW
EXECUTE FUNCTION lowercase_wallet_address();

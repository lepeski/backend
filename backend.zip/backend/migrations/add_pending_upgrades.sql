-- Add unique constraint to wallet addresses (one wallet per player)
ALTER TABLE player_wallets
ADD CONSTRAINT unique_wallet_address UNIQUE (wallet_address);

-- Create pending_upgrades table
CREATE TABLE IF NOT EXISTS pending_upgrades (
    id SERIAL PRIMARY KEY,
    player_uuid VARCHAR(36) NOT NULL,
    wallet_address VARCHAR(42) NOT NULL,
    beacon_key VARCHAR(255) NOT NULL,
    contract_address VARCHAR(42) NOT NULL,
    payment_amount VARCHAR(78) NOT NULL, -- Store as string to avoid precision issues
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,
    status VARCHAR(20) DEFAULT 'pending', -- pending, paid, cancelled, expired

    -- Only one pending upgrade per wallet at a time
    CONSTRAINT unique_pending_per_wallet UNIQUE (wallet_address, status),

    -- Foreign key to player_wallets
    CONSTRAINT fk_wallet
        FOREIGN KEY (wallet_address)
        REFERENCES player_wallets(wallet_address)
        ON DELETE CASCADE
);

-- Index for faster lookups
CREATE INDEX idx_pending_wallet ON pending_upgrades(wallet_address, status);
CREATE INDEX idx_pending_beacon ON pending_upgrades(beacon_key, status);
CREATE INDEX idx_pending_expires ON pending_upgrades(expires_at, status);

-- Add comments
COMMENT ON TABLE pending_upgrades IS 'Tracks pending beacon upgrade payments';
COMMENT ON COLUMN pending_upgrades.payment_amount IS 'Expected payment amount in pDAI wei (as string)';
COMMENT ON COLUMN pending_upgrades.status IS 'pending = awaiting payment, paid = payment detected, cancelled = player cancelled, expired = timeout';

-- Migration: Add crystal status column and audit logging
-- Created: 2026-01-06
-- Purpose: Enable state machine for crystal lifecycle tracking

-- ============================================================
-- PART 1: Add status column to crystals table
-- ============================================================

-- For MySQL
ALTER TABLE crystals ADD COLUMN status ENUM(
    'DORMANT',
    'ACTIVE',
    'HELD',
    'REDEEMING',
    'REDEEMED',
    'LOST'
) DEFAULT 'HELD' AFTER redeemed;

-- Add metadata column for state transition tracking
ALTER TABLE crystals ADD COLUMN metadata JSON AFTER status;

-- Add updated_at timestamp
ALTER TABLE crystals ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER metadata;

-- Create index for status queries
CREATE INDEX idx_crystal_status ON crystals(status);
CREATE INDEX idx_crystal_updated ON crystals(updated_at);

-- ============================================================
-- PART 2: Migrate existing data
-- ============================================================

-- Set status based on existing redeemed flag
UPDATE crystals
SET status = CASE
    WHEN redeemed = TRUE THEN 'REDEEMED'
    ELSE 'HELD'
END;

-- Initialize metadata as empty JSON object
UPDATE crystals SET metadata = '{}' WHERE metadata IS NULL;

-- ============================================================
-- PART 3: Create audit_log table
-- ============================================================

CREATE TABLE IF NOT EXISTS audit_log (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    event_type VARCHAR(50) NOT NULL,
    user_id VARCHAR(255),
    crystal_id VARCHAR(255),
    beacon_id VARCHAR(255),
    success BOOLEAN,
    error TEXT,
    ip_address VARCHAR(45),
    metadata JSON,
    timestamp BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_audit_timestamp (timestamp),
    INDEX idx_audit_event_type (event_type),
    INDEX idx_audit_crystal (crystal_id),
    INDEX idx_audit_user (user_id),
    INDEX idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- PART 4: PostgreSQL Alternative (commented out)
-- ============================================================

-- For PostgreSQL, use this instead:
/*
-- Add status column with enum type
CREATE TYPE crystal_status AS ENUM (
    'DORMANT',
    'ACTIVE',
    'HELD',
    'REDEEMING',
    'REDEEMED',
    'LOST'
);

ALTER TABLE crystals ADD COLUMN status crystal_status DEFAULT 'HELD';
ALTER TABLE crystals ADD COLUMN metadata JSONB;
ALTER TABLE crystals ADD COLUMN updated_at TIMESTAMP DEFAULT NOW();

-- Create indexes
CREATE INDEX idx_crystal_status ON crystals(status);
CREATE INDEX idx_crystal_updated ON crystals(updated_at);

-- Migrate existing data
UPDATE crystals
SET status = CASE
    WHEN redeemed = TRUE THEN 'REDEEMED'::crystal_status
    ELSE 'HELD'::crystal_status
END;

UPDATE crystals SET metadata = '{}'::jsonb WHERE metadata IS NULL;

-- Create audit log table
CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    user_id VARCHAR(255),
    crystal_id VARCHAR(255),
    beacon_id VARCHAR(255),
    success BOOLEAN,
    error TEXT,
    ip_address VARCHAR(45),
    metadata JSONB,
    timestamp BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_audit_timestamp ON audit_log(timestamp);
CREATE INDEX idx_audit_event_type ON audit_log(event_type);
CREATE INDEX idx_audit_crystal ON audit_log(crystal_id);
CREATE INDEX idx_audit_user ON audit_log(user_id);
CREATE INDEX idx_audit_created ON audit_log(created_at);
*/

-- ============================================================
-- VERIFICATION QUERIES
-- ============================================================

-- Check migration success
-- SELECT COUNT(*) as total, status, COUNT(*) as count
-- FROM crystals
-- GROUP BY status;

-- Check audit log table
-- SELECT COUNT(*) FROM audit_log;

-- Migration: PostgreSQL Schema Fix
-- Created: 2026-01-08
-- Purpose: Add missing columns and tables for PostgreSQL

-- ============================================================
-- PART 1: Add missing columns to crystals table
-- ============================================================

-- Add status column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name='crystals' AND column_name='status'
    ) THEN
        ALTER TABLE crystals ADD COLUMN status VARCHAR(20) DEFAULT 'HELD';
    END IF;
END $$;

-- Add metadata column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name='crystals' AND column_name='metadata'
    ) THEN
        ALTER TABLE crystals ADD COLUMN metadata JSONB;
    END IF;
END $$;

-- Add updated_at column if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_name='crystals' AND column_name='updated_at'
    ) THEN
        ALTER TABLE crystals ADD COLUMN updated_at TIMESTAMP DEFAULT NOW();
    END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_crystal_status ON crystals(status);
CREATE INDEX IF NOT EXISTS idx_crystal_redeemed ON crystals(redeemed);
CREATE INDEX IF NOT EXISTS idx_crystal_created ON crystals(created_at);

-- ============================================================
-- PART 2: Create audit_log table
-- ============================================================

CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    event_type VARCHAR(50) NOT NULL,
    user_id VARCHAR(255),
    crystal_id VARCHAR(255),
    beacon_id VARCHAR(255),
    success BOOLEAN,
    error TEXT,
    ip_address VARCHAR(45),
    metadata JSONB,
    timestamp BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_event_type ON audit_log(event_type);
CREATE INDEX IF NOT EXISTS idx_audit_crystal ON audit_log(crystal_id);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);

-- ============================================================
-- VERIFICATION QUERIES
-- ============================================================

-- Check tables exist
-- SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' AND table_name IN ('crystals', 'audit_log');

-- Check crystal count
-- SELECT COUNT(*) as total, status, COUNT(*) as count FROM crystals GROUP BY status;

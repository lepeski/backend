/**
 * Check if a beacon is registered on-chain
 */

const db = require('./services/databaseService');
const contractService = require('./services/contractService');
const { ethers } = require('ethers');
const logger = require('./utils/logger');

// Convert beacon UUID to bytes32
function beaconUuidToBytes32(uuid) {
    return ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(['string'], [uuid]));
}

async function checkBeacon() {
    try {
        logger.info('Checking beacon registration...');

        // Connect to database
        await db.connect();

        // Initialize contract service
        await contractService.initialize();

        // Get beacons from database
        const beacons = await db.query(`SELECT * FROM beacons ORDER BY created_at DESC LIMIT 5`);

        if (!beacons || beacons.length === 0) {
            logger.warn('No beacons found in database');
            process.exit(0);
        }

        logger.info(`Found ${beacons.length} beacons in database:`);

        for (const beacon of beacons) {
            const beaconKey = beacon.beacon_key || beacon.id;
            const beaconIdBytes32 = beaconUuidToBytes32(beaconKey);

            logger.info(`\nBeacon: ${beaconKey}`);
            logger.info(`  Bytes32: ${beaconIdBytes32}`);
            logger.info(`  Status: ${beacon.status || 'UNKNOWN'}`);

            // Try to read beacon from contract
            try {
                const onChainBeacon = await contractService.contract.beacons(beaconIdBytes32);
                logger.info(`  On-chain: ${JSON.stringify(onChainBeacon)}`);

                if (onChainBeacon && onChainBeacon.isActive) {
                    logger.info(`  ✅ Beacon is active on-chain`);
                } else {
                    logger.warn(`  ❌ Beacon NOT active on-chain`);
                }
            } catch (error) {
                logger.error(`  Error reading beacon: ${error.message}`);
            }
        }

        // Also check the specific beacon being used
        const testBeacon = 'world:-103:63:46';
        const testBeaconBytes32 = beaconUuidToBytes32(testBeacon);

        logger.info(`\n\nTest beacon: ${testBeacon}`);
        logger.info(`  Bytes32: ${testBeaconBytes32}`);

        try {
            const onChainBeacon = await contractService.contract.beacons(testBeaconBytes32);
            logger.info(`  On-chain data: ${JSON.stringify(onChainBeacon)}`);

            if (onChainBeacon && onChainBeacon.isActive) {
                logger.info(`  ✅ Test beacon is active on-chain!`);
            } else {
                logger.warn(`  ❌ Test beacon NOT active on-chain!`);
                logger.warn(`  This is why redemptions are failing!`);
            }
        } catch (error) {
            logger.error(`  Error: ${error.message}`);
        }

        process.exit(0);
    } catch (error) {
        logger.logError(error, { context: 'Check beacon' });
        process.exit(1);
    }
}

checkBeacon();

const express = require('express');
const cors = require('cors');
const cron = require('node-cron');
const config = require('./config/config');
const logger = require('./utils/logger');
const db = require('./services/databaseService');
const contractService = require('./services/contractService');
const merkleService = require('./services/merkleService');
const redemptionService = require('./services/redemptionService');
const paymentMonitoring = require('./services/paymentMonitoringService');
const { globalLimiter } = require('./middleware/rateLimit');

// Import routes
const redemptionRoutes = require('./routes/redemption');
const crystalRoutes = require('./routes/crystals');
const beaconRoutes = require('./routes/beacons');
const walletRoutes = require('./routes/wallet');
const adminRoutes = require('./routes/admin');

// Initialize Express app
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Trust proxy (for rate limiting by IP)
app.set('trust proxy', 1);

// Global rate limiter
app.use(globalLimiter);

// Serve static files (upgrade UI)
app.use(express.static('public'));

// Health check endpoint (no auth required)
app.get('/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
    });
});

// Mount API routes
app.use('/api', redemptionRoutes);
app.use('/api/crystals', crystalRoutes);
app.use('/api/beacon', beaconRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/admin', adminRoutes);

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        error: 'Endpoint not found'
    });
});

// Error handler
app.use((err, req, res, next) => {
    logger.logError(err, {
        context: 'Express error handler',
        path: req.path,
        method: req.method
    });

    res.status(500).json({
        error: 'Internal server error'
    });
});

/**
 * Initialize services and start server
 */
async function start() {
    try {
        logger.info('Starting CrystalMath Backend Server...');

        // 1. Connect to database
        logger.info('Connecting to database...');
        await db.connect();
        logger.info('Database connected successfully');

        // 2. Initialize contract service
        logger.info('Initializing contract service...');
        await contractService.initialize();
        logger.info('Contract service initialized');

        // 3. Initialize payment monitoring
        logger.info('Initializing payment monitoring...');
        await paymentMonitoring.initialize();
        await paymentMonitoring.startMonitoring();
        logger.info('Payment monitoring started');

        // 4. Load Merkle tree from file (if exists)
        try {
            logger.info('Loading Merkle tree from file...');
            merkleService.loadFromFile();
            logger.info(`Merkle tree loaded. Root: ${merkleService.getRoot()}`);
        } catch (error) {
            logger.warn('No existing Merkle tree found. Will rebuild on first crystal notification.');
        }

        // 5. Start server
        const PORT = config.port;
        app.listen(PORT, () => {
            logger.info(`Server running on port ${PORT}`);
            logger.info(`Environment: ${config.nodeEnv}`);
            logger.info(`Network: ${config.blockchain.chainId === 369 ? 'PulseChain' : 'Unknown'}`);
            logger.info(`Contract: ${config.contracts.crystalRedemption}`);
            logger.info('CrystalMath Backend Ready!');
        });

        // ==================================================================
        // AUTOMATIC QUEUE PROCESSING
        // ==================================================================

        // Configuration from environment with validation
        const autoProcessEnabled = process.env.AUTO_PROCESS_ENABLED === 'true';
        const autoProcessInterval = Math.max(1, Math.min(60, parseInt(process.env.AUTO_PROCESS_INTERVAL_MINUTES) || 15));
        const autoProcessBatchSize = Math.max(1, Math.min(100, parseInt(process.env.AUTO_PROCESS_BATCH_SIZE) || 20));
        const autoProcessMaxGas = Math.max(1, parseInt(process.env.AUTO_PROCESS_MAX_GAS_GWEI) || 10);
        const autoRetryQueuedEnabled = process.env.AUTO_RETRY_QUEUED_ENABLED === 'true';
        const autoRetryQueuedInterval = Math.max(1, Math.min(60, parseInt(process.env.AUTO_RETRY_QUEUED_INTERVAL_MINUTES) || 5));

        if (autoProcessEnabled) {
            logger.info('🤖 Automatic redemption processing ENABLED', {
                interval: `${autoProcessInterval} minutes`,
                batchSize: autoProcessBatchSize,
                maxGasGwei: autoProcessMaxGas
            });

            // Auto-process pending redemptions
            cron.schedule(`*/${autoProcessInterval} * * * *`, async () => {
                try {
                    logger.info('⏰ Auto-processing redemption queue...');

                    const pending = await db.getPendingRedemptions();

                    if (pending.length === 0) {
                        logger.info('✓ No pending redemptions to process');
                        return;
                    }

                    const toProcess = pending.slice(0, autoProcessBatchSize);

                    logger.info(`Processing ${toProcess.length} of ${pending.length} pending redemptions`);

                    const result = await redemptionService.processRedemptionBatch(toProcess, {
                        skipGasCheck: false,
                        maxGasGwei: autoProcessMaxGas
                    });

                    if (result.success) {
                        logger.info('✅ Auto-processing complete', {
                            total: result.processed,
                            successful: result.successful,
                            failed: result.failed,
                            remaining: pending.length - result.processed
                        });
                    } else {
                        logger.warn('⚠️  Auto-processing skipped', {
                            reason: result.error,
                            gasPrice: result.gasPrice,
                            skipped: result.skipped
                        });
                    }

                } catch (error) {
                    logger.logError(error, { context: 'Auto-process queue' });
                }
            });

            logger.info(`✓ Auto-processing scheduled: every ${autoProcessInterval} minutes`);
        } else {
            logger.info('ℹ️  Automatic redemption processing DISABLED (manual processing only)');
        }

        // Auto-retry queued redemptions when gas drops
        if (autoRetryQueuedEnabled) {
            logger.info('🤖 Automatic retry for queued redemptions ENABLED', {
                interval: `${autoRetryQueuedInterval} minutes`
            });

            cron.schedule(`*/${autoRetryQueuedInterval} * * * *`, async () => {
                try {
                    const result = await redemptionService.retryQueuedRedemptions();

                    if (result.moved > 0) {
                        logger.info(`✅ Moved ${result.moved} queued redemptions to pending`, {
                            gasPrice: result.gasPrice
                        });
                    }

                } catch (error) {
                    logger.logError(error, { context: 'Auto-retry queued' });
                }
            });

            logger.info(`✓ Auto-retry scheduled: every ${autoRetryQueuedInterval} minutes`);
        }

    } catch (error) {
        logger.logError(error, { context: 'Server startup' });
        process.exit(1);
    }
}

/**
 * Graceful shutdown
 */
async function shutdown(signal) {
    logger.info(`${signal} received. Starting graceful shutdown...`);

    try {
        // Close database connection
        await db.close();
        logger.info('Database connection closed');

        logger.info('Shutdown complete');
        process.exit(0);
    } catch (error) {
        logger.logError(error, { context: 'Shutdown' });
        process.exit(1);
    }
}

// Handle shutdown signals
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Handle unhandled rejections
process.on('unhandledRejection', (reason, promise) => {
    logger.logError(new Error('Unhandled Rejection'), {
        context: 'Unhandled Promise Rejection',
        reason: reason
    });
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
    logger.logError(error, { context: 'Uncaught Exception' });
    process.exit(1);
});

// Start the server
start();

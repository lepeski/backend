/**
 * Clean database script - removes all data for a fresh start
 * WARNING: This will delete all data!
 */

const db = require('./services/databaseService');
const logger = require('./utils/logger');

async function cleanDatabase() {
    try {
        logger.info('Starting database cleanup...');

        // List of tables to clean (in order to handle foreign keys)
        const tablesToClean = [
            'audit_log',
            'redemption_queue',
            'pending_beacon_upgrades',
            'crystal_status_history',
            'crystals',
            'beacons',
            'player_wallets'
        ];

        for (const table of tablesToClean) {
            try {
                const result = await db.query(`DELETE FROM ${table}`);
                const count = result?.rowCount || 0;
                logger.info(`✓ Cleaned ${table}: ${count} rows deleted`);
            } catch (error) {
                // Table might not exist, that's okay
                logger.warn(`⚠ Skipped ${table}: ${error.message}`);
            }
        }

        // Reset sequences (auto-increment IDs)
        try {
            const sequences = await db.query(`
                SELECT sequence_name
                FROM information_schema.sequences
                WHERE sequence_schema = 'public'
            `);

            for (const seq of sequences) {
                await db.query(`ALTER SEQUENCE ${seq.sequence_name} RESTART WITH 1`);
                logger.info(`✓ Reset sequence: ${seq.sequence_name}`);
            }
        } catch (error) {
            logger.warn('Could not reset sequences:', error.message);
        }

        logger.info('✅ Database cleaned successfully!');
        logger.info('');
        logger.info('Next steps:');
        logger.info('1. Restart the backend server');
        logger.info('2. Delete the Minecraft world (or just the claims.json file)');
        logger.info('3. Delete backend/testnet-data/merkle-tree.json');
        logger.info('4. Start fresh!');

        process.exit(0);
    } catch (error) {
        logger.logError(error, { context: 'Database cleanup' });
        process.exit(1);
    }
}

cleanDatabase();

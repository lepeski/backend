# CrystalMath Backend API Examples

Quick reference for testing API endpoints with curl commands.

## Setup

Set these variables for easier testing:

```bash
export API_KEY="your-api-key-here"
export API_URL="http://localhost:3000"
export ADMIN_USER="admin"
export ADMIN_PASS="your-admin-password"
```

## Health Check

```bash
curl $API_URL/health
```

## Wallet Linking

### Link a wallet to player UUID

```bash
curl -X POST $API_URL/api/wallet/link \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "playerUuid": "123e4567-e89b-12d3-a456-426614174000",
    "walletAddress": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
  }'
```

### Get player's linked wallet

```bash
curl $API_URL/api/wallet/123e4567-e89b-12d3-a456-426614174000 \
  -H "X-API-Key: $API_KEY"
```

## Beacon Management

### Register single beacon

```bash
curl -X POST $API_URL/api/beacon/register \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "beaconId": "beacon-uuid-123",
    "ownerAddress": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
  }'
```

### Batch register beacons

```bash
curl -X POST $API_URL/api/beacon/batch-register \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "beacons": [
      {
        "beaconId": "beacon-uuid-1",
        "ownerAddress": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
      },
      {
        "beaconId": "beacon-uuid-2",
        "ownerAddress": "0x8Ba1f109551bD432803012645Ac136ddd64DBA72"
      }
    ]
  }'
```

### Get beacon info

```bash
curl $API_URL/api/beacon/beacon-uuid-123 \
  -H "X-API-Key: $API_KEY"
```

### Get all active beacons

```bash
curl $API_URL/api/beacon/list/active \
  -H "X-API-Key: $API_KEY"
```

## Crystal Management

### Notify new crystal

```bash
curl -X POST $API_URL/api/crystals/new \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "crystalId": "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
  }'
```

### Get Merkle proof

```bash
curl "$API_URL/api/merkle/proof/0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
```

## Redemption

### Request redemption

```bash
curl -X POST $API_URL/api/redeem \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "123e4567-e89b-12d3-a456-426614174000",
    "crystalId": "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef",
    "payoutToken": "0x6B175474E89094C44Da98b954EedeAC495271d0F",
    "minAmountOut": "0"
  }'
```

### Check redemption status

```bash
curl $API_URL/api/redemption/status/123
```

### Get current gas price

```bash
curl $API_URL/api/gas/current
```

## Admin Operations

### Process pending redemptions

```bash
curl -X POST $API_URL/api/admin/process-batch \
  -u $ADMIN_USER:$ADMIN_PASS \
  -H "Content-Type: application/json" \
  -d '{
    "limit": 10
  }'
```

### Retry queued redemptions

```bash
curl -X POST $API_URL/api/admin/retry-queued \
  -u $ADMIN_USER:$ADMIN_PASS
```

### Get statistics

```bash
curl $API_URL/api/admin/stats \
  -u $ADMIN_USER:$ADMIN_PASS
```

### Manual Merkle root update

```bash
curl -X POST $API_URL/api/admin/merkle/update \
  -u $ADMIN_USER:$ADMIN_PASS
```

### Get pending redemptions

```bash
curl $API_URL/api/admin/redemptions/pending \
  -u $ADMIN_USER:$ADMIN_PASS
```

### Get queued redemptions

```bash
curl $API_URL/api/admin/redemptions/queued \
  -u $ADMIN_USER:$ADMIN_PASS
```

### Get contract tax rates

```bash
curl $API_URL/api/admin/contract/tax-rates \
  -u $ADMIN_USER:$ADMIN_PASS
```

### Deactivate beacon

```bash
curl -X POST $API_URL/api/admin/beacon/deactivate \
  -u $ADMIN_USER:$ADMIN_PASS \
  -H "Content-Type: application/json" \
  -d '{
    "beaconId": "beacon-uuid-123"
  }'
```

### Get failed attempts (last 24 hours)

```bash
curl "$API_URL/api/admin/security/failed-attempts?hours=24" \
  -u $ADMIN_USER:$ADMIN_PASS
```

## Testing Workflow

### 1. Link a wallet

```bash
curl -X POST $API_URL/api/wallet/link \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "playerUuid": "test-player-uuid",
    "walletAddress": "0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb"
  }'
```

### 2. Register a beacon

```bash
curl -X POST $API_URL/api/beacon/register \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "beaconId": "test-beacon-uuid",
    "ownerAddress": "0x8Ba1f109551bD432803012645Ac136ddd64DBA72"
  }'
```

### 3. Add a crystal to database

(This would normally be done by the Minecraft plugin when a crystal is generated)

```bash
# Insert crystal directly into database for testing
mysql -u crystalmath_user -p crystalmath -e "
INSERT INTO crystals (id, beacon_id, owner_user_id, owner_address)
VALUES (
  '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef',
  'test-beacon-uuid',
  'test-player-uuid',
  '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb'
)"
```

### 4. Notify backend of new crystal

```bash
curl -X POST $API_URL/api/crystals/new \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "crystalId": "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
  }'
```

### 5. Request redemption

```bash
curl -X POST $API_URL/api/redeem \
  -H "X-API-Key: $API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "userId": "test-player-uuid",
    "crystalId": "0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef"
  }'
```

### 6. Process redemption (admin)

```bash
curl -X POST $API_URL/api/admin/process-batch \
  -u $ADMIN_USER:$ADMIN_PASS \
  -H "Content-Type: application/json" \
  -d '{"limit": 10}'
```

## Response Examples

### Successful Redemption Request

```json
{
  "success": true,
  "queued": false,
  "message": "Redemption queued for admin approval",
  "queueId": 1,
  "queuePosition": 1,
  "gasPrice": 15.2,
  "payoutToken": "pDAI"
}
```

### Queued Due to High Gas

```json
{
  "success": true,
  "queued": true,
  "message": "Gas price too high (45.5 Gwei). Your redemption has been queued and will be processed when gas drops below 9% of value.",
  "gasPrice": 45.5,
  "threshold": 0.000117
}
```

### Ownership Failed

```json
{
  "error": "You do not own this crystal"
}
```

### Process Batch Results

```json
{
  "success": true,
  "processed": 5,
  "successful": 4,
  "failed": 1,
  "results": {
    "successful": [
      {
        "redemptionId": 1,
        "crystalId": "0x...",
        "txHash": "0x..."
      }
    ],
    "failed": [
      {
        "redemptionId": 5,
        "crystalId": "0x...",
        "error": "Beacon not active"
      }
    ]
  }
}
```

## Notes

- Replace `$API_KEY`, `$ADMIN_USER`, and `$ADMIN_PASS` with actual credentials
- Crystal IDs must be 66 characters (0x + 64 hex chars)
- Ethereum addresses must be 42 characters (0x + 40 hex chars)
- All timestamps are in ISO 8601 format
- Rate limits apply - max 10 redemptions per hour per user

/**
 * Check contract state - is it initialized, paused, etc?
 */

const contractService = require('./services/contractService');
const { ethers } = require('ethers');
const logger = require('./utils/logger');

// Convert beacon UUID to bytes32
function beaconUuidToBytes32(uuid) {
    return ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(['string'], [uuid]));
}

async function checkContractState() {
    try {
        logger.info('Checking contract state...');

        await contractService.initialize();

        const contract = contractService.contract;

        // Check basic contract state
        logger.info('\n=== Contract Info ===');
        logger.info(`Address: ${await contract.getAddress()}`);

        // Try to read various contract states
        const checks = [
            { name: 'owner', call: () => contract.owner() },
            { name: 'paused', call: () => contract.paused() },
            { name: 'initialized', call: () => contract.initialized() },
            { name: 'merkleRoot', call: () => contract.merkleRoot() },
            { name: 'getMerkleRoot', call: () => contract.getMerkleRoot() },
        ];

        for (const check of checks) {
            try {
                const value = await check.call();
                logger.info(`${check.name}: ${value}`);
            } catch (e) {
                // Function doesn't exist, skip
            }
        }

        // Check the specific beacon
        logger.info('\n=== Beacon Check ===');
        const beaconKey = 'world:-103:63:46';
        const beaconIdBytes32 = beaconUuidToBytes32(beaconKey);

        logger.info(`Beacon Key: ${beaconKey}`);
        logger.info(`Beacon ID (bytes32): ${beaconIdBytes32}`);

        try {
            const beacon = await contract.beacons(beaconIdBytes32);
            logger.info(`Beacon data: ${JSON.stringify(beacon, (key, value) =>
                typeof value === 'bigint' ? value.toString() : value
            , 2)}`);

            // Try to access beacon properties
            if (beacon) {
                try {
                    logger.info(`  owner: ${beacon.owner || beacon[0]}`);
                    logger.info(`  isActive: ${beacon.isActive || beacon[1]}`);
                    logger.info(`  crystalsIssued: ${beacon.crystalsIssued || beacon[2]}`);
                } catch (e) {
                    logger.info('  (Could not parse beacon struct)');
                }
            }
        } catch (e) {
            logger.error(`Error reading beacon: ${e.message}`);
        }

        // Check if we can read the Merkle root
        logger.info('\n=== Merkle Root ===');
        try {
            // Try different ways to read Merkle root
            let root;
            try {
                root = await contract.merkleRoot();
            } catch (e) {
                try {
                    root = await contract.getMerkleRoot();
                } catch (e2) {
                    try {
                        root = await contract.currentMerkleRoot();
                    } catch (e3) {
                        logger.error('Cannot read Merkle root from contract');
                    }
                }
            }

            if (root) {
                logger.info(`Contract Merkle Root: ${root}`);
            }
        } catch (e) {
            logger.error(`Error reading Merkle root: ${e.message}`);
        }

        // Check pDAI balance
        logger.info('\n=== Contract Balance ===');
        try {
            const balance = await contractService.getContractBalance();
            logger.info(`pDAI Balance: ${ethers.formatEther(balance)} pDAI`);
        } catch (e) {
            logger.error(`Error reading balance: ${e.message}`);
        }

        process.exit(0);
    } catch (error) {
        logger.logError(error, { context: 'Check contract state' });
        process.exit(1);
    }
}

checkContractState();

/**
 * Debug the redemption transaction to see what's being sent
 */

const { ethers } = require('ethers');
const contractService = require('./services/contractService');
const merkleService = require('./services/merkleService');
const logger = require('./utils/logger');

// The actual transaction data from the error
const errorTxData = "0x79d57cc64cb4d498625d17dc9aad77f892d5d69325b02e1c9de4ae9f2103c03077145bd5d1ac1263080adf32c6a10d8a2fc8741be65f3b3952e373f7bf353203d0157a7b000000000000000000000000030deb27e8e8fb1f600dd520305ddf954326f0ce00000000000000000000000000000000000000000000000000000000000000800000000000000000000000000000000000000000000000000000000000000002096894a1ba922bc4e0a665f0066bc7d017467ecf265ddd169ae5a262fe9a94a0aaef61ff500dbdcff39c89547c78f5e0d87cdd5ace98252f10c8e4781102ab93";

async function debugRedemptionCall() {
    try {
        logger.info('Debugging redemption call...');

        // Initialize contract
        await contractService.initialize();

        // Get function selector
        const selector = errorTxData.slice(0, 10);
        logger.info(`Function selector: ${selector}`);

        // Try to decode the calldata
        try {
            const iface = contractService.contract.interface;

            // List all functions in the contract
            logger.info('\nContract functions:');
            const functions = Object.keys(iface.functions);
            functions.forEach(f => {
                const func = iface.functions[f];
                logger.info(`  ${func.name}(${func.inputs.map(i => i.type).join(', ')}) - selector: ${func.selector}`);
            });

            // Try to decode the transaction data
            logger.info('\nDecoding transaction data...');
            const decoded = iface.parseTransaction({ data: errorTxData });

            if (decoded) {
                logger.info(`Function: ${decoded.name}`);
                logger.info(`Arguments:`);
                decoded.args.forEach((arg, i) => {
                    const input = decoded.fragment.inputs[i];
                    logger.info(`  ${input.name} (${input.type}): ${arg}`);
                });
            }
        } catch (decodeError) {
            logger.error(`Could not decode: ${decodeError.message}`);
        }

        // Check if the contract has the redeemCrystal function
        logger.info('\nLooking for redeemCrystal function...');
        const redeemFunc = contractService.contract.interface.getFunction('redeemCrystal');

        if (redeemFunc) {
            logger.info(`Found redeemCrystal function!`);
            logger.info(`Expected signature: ${redeemFunc.format()}`);
            logger.info(`Expected selector: ${redeemFunc.selector}`);
            logger.info(`Actual selector:   ${selector}`);

            if (redeemFunc.selector === selector) {
                logger.info('✅ Selectors match!');
            } else {
                logger.error('❌ Selectors DO NOT match! ABI mismatch!');
            }
        } else {
            logger.error('❌ redeemCrystal function not found in contract ABI!');
        }

        // Try to simulate the call
        logger.info('\nAttempting to simulate the call...');
        try {
            // Extract parameters from the transaction data
            const crystalId = "0x4cb4d498625d17dc9aad77f892d5d69325b02e1c9de4ae9f2103c03077145bd5";
            const beaconId = "0xd1ac1263080adf32c6a10d8a2fc8741be65f3b3952e373f7bf353203d0157a7b";
            const payoutAddress = "0x030deb27e8e8fb1f600dd520305ddf954326f0ce";
            const proof = [
                "0x096894a1ba922bc4e0a665f0066bc7d017467ecf265ddd169ae5a262fe9a94a0",
                "0xaaef61ff500dbdcff39c89547c78f5e0d87cdd5ace98252f10c8e4781102ab93"
            ];

            logger.info('Call parameters:');
            logger.info(`  crystalId: ${crystalId}`);
            logger.info(`  beaconId: ${beaconId}`);
            logger.info(`  payoutAddress: ${payoutAddress}`);
            logger.info(`  proof: [${proof.join(', ')}]`);

            // Try static call
            const result = await contractService.contract.redeemCrystal.staticCall(
                crystalId,
                beaconId,
                payoutAddress,
                proof
            );

            logger.info('✅ Static call succeeded!');
            logger.info(`Result: ${result}`);
        } catch (staticError) {
            logger.error(`❌ Static call failed: ${staticError.message}`);

            // Check specific error reasons
            if (staticError.message.includes('Beacon not active')) {
                logger.error('→ Beacon is not registered or not active on-chain!');
            } else if (staticError.message.includes('Invalid proof')) {
                logger.error('→ Merkle proof is invalid!');
            } else if (staticError.message.includes('Crystal already redeemed')) {
                logger.error('→ Crystal has already been redeemed!');
            } else {
                logger.error('→ Unknown error. Contract might have other requirements.');
            }
        }

        process.exit(0);
    } catch (error) {
        logger.logError(error, { context: 'Debug redemption call' });
        process.exit(1);
    }
}

debugRedemptionCall();

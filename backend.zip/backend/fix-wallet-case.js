const { Client } = require('pg');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

async function fixWalletCase() {
    const client = new Client({
        host: process.env.DB_HOST || 'localhost',
        port: process.env.DB_PORT || 5432,
        database: process.env.DB_NAME || 'crystalmath_testnet',
        user: process.env.DB_USER || 'postgres',
        password: process.env.DB_PASSWORD
    });

    try {
        await client.connect();
        console.log('Connected to database');

        const sql = fs.readFileSync(path.join(__dirname, 'migrations/fix_wallet_case.sql'), 'utf8');

        console.log('Normalizing wallet addresses to lowercase...');
        await client.query(sql);

        console.log('✅ Wallet addresses normalized!');

        // Verify
        const result = await client.query(`
            SELECT wallet_address FROM player_wallets
        `);

        console.log('\nWallet addresses in database:');
        result.rows.forEach(row => {
            console.log('  -', row.wallet_address);
        });

    } catch (error) {
        console.error('❌ Migration failed:', error.message);
        process.exit(1);
    } finally {
        await client.end();
    }
}

fixWalletCase();

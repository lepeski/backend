# CrystalMath Backend API Server

Backend API server for the CrystalMath crystal redemption system - handles blockchain interactions, Merkle tree management, and redemption queue processing for Minecraft plugin integration.

## Features

- **Crystal Redemption Queue**: Secure request processing with ownership verification
- **Gas Threshold Monitoring**: Automatic 9% rule enforcement - queues redemptions when gas is too high
- **Merkle Tree Management**: Automated tree building and on-chain root updates
- **Beacon Registration**: On-chain beacon whitelisting with batch support
- **Wallet Linking**: Links Minecraft player UUIDs to Ethereum addresses
- **Security Features**:
  - API key authentication for plugin
  - Basic auth for admin endpoints
  - Rate limiting (10 redemptions/hour per user)
  - Ownership verification
  - Failed attempt logging
- **Multi-Database Support**: MySQL and PostgreSQL
- **Admin Dashboard Endpoints**: Process batches, view stats, emergency controls

## Architecture

```
┌─────────────────┐
│ Minecraft Plugin│
│   (Java)        │
└────────┬────────┘
         │ HTTP API
         │ (X-API-Key auth)
         ▼
┌─────────────────────────────────────┐
│   Backend API Server (Node.js)      │
│                                     │
│  ┌──────────────┐  ┌─────────────┐ │
│  │   Routes     │  │  Services   │ │
│  │              │  │             │ │
│  │ - Redemption │  │ - Database  │ │
│  │ - Crystals   │  │ - Merkle    │ │
│  │ - Beacons    │  │ - Contract  │ │
│  │ - Wallet     │  │ - Gas       │ │
│  │ - Admin      │  │             │ │
│  └──────────────┘  └─────────────┘ │
│                                     │
│  ┌──────────────┐  ┌─────────────┐ │
│  │  Middleware  │  │   Utils     │ │
│  │              │  │             │ │
│  │ - Auth       │  │ - Logger    │ │
│  │ - RateLimit  │  │ - Config    │ │
│  │ - Validation │  │             │ │
│  └──────────────┘  └─────────────┘ │
└───────────┬─────────────────────────┘
            │
            ▼
     ┌──────────────┐
     │  Database    │
     │ (MySQL/PG)   │
     └──────────────┘
            │
            ▼
     ┌──────────────┐
     │  PulseChain  │
     │  Smart       │
     │  Contract    │
     └──────────────┘
```

## Prerequisites

- Node.js v16 or higher
- MySQL 8.0+ or PostgreSQL 12+
- PulseChain RPC access
- Server wallet with PLS for gas

## Installation

1. **Clone and navigate to backend directory**:
   ```bash
   cd backend
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Configure environment** (see Configuration section below)

4. **Run database migrations**:
   ```bash
   npm run migrate
   ```

5. **Start the server**:
   ```bash
   # Production
   npm start

   # Development (with auto-reload)
   npm run dev
   ```

## Configuration

Copy `.env.example` to `.env` and configure:

### Required Variables

```env
# Server
NODE_ENV=production
PORT=3000
API_SECRET=your-secure-api-key-here

# Database (choose MySQL or PostgreSQL)
DB_TYPE=mysql
DB_HOST=localhost
DB_PORT=3306
DB_NAME=crystalmath
DB_USER=crystalmath_user
DB_PASSWORD=secure_password_here

# PulseChain
PULSECHAIN_RPC_URL=https://rpc.pulsechain.com
CHAIN_ID=369

# Smart Contracts
CONTRACT_ADDRESS=0x...  # CrystalRedemptionUnified contract
PDAI_ADDRESS=0x6B175474E89094C44Da98b954EedeAC495271d0F  # pDAI on PulseChain
PULSEX_ROUTER_ADDRESS=0x...  # PulseX Router V2

# Server Wallet (hot wallet for gas)
SERVER_PRIVATE_KEY=0x...  # Private key (DO NOT COMMIT)
SERVER_ADDRESS=0x...      # Server wallet address

# Admin Auth
ADMIN_USERNAME=admin
ADMIN_PASSWORD=secure_admin_password_here
```

### Optional Variables

```env
# Pricing (for gas threshold calculations)
PDAI_PRICE_USD=0.0013
PLS_PRICE_USD=0.0001

# Gas Settings
MAX_GAS_PERCENTAGE=9        # Reject if gas > 9% of user value
ESTIMATED_GAS=85000         # Estimated gas units for redemption

# Rate Limiting
RATE_LIMIT_WINDOW_MS=3600000  # 1 hour
RATE_LIMIT_MAX_REQUESTS=10     # 10 redemptions per hour
```

## API Endpoints

### Redemption

#### POST /api/redeem
Request crystal redemption.

**Auth**: X-API-Key (plugin)

**Body**:
```json
{
  "userId": "minecraft-player-uuid",
  "crystalId": "0x...",
  "payoutToken": "0x..." (optional),
  "minAmountOut": "0" (optional)
}
```

**Response**:
```json
{
  "success": true,
  "queued": false,
  "message": "Redemption queued for admin approval",
  "queueId": 123,
  "queuePosition": 5,
  "gasPrice": 15.2,
  "payoutToken": "pDAI"
}
```

#### GET /api/redemption/status/:id
Get redemption status.

#### GET /api/gas/current
Get current gas price and threshold info.

### Crystals

#### POST /api/crystals/new
Notify backend of new crystal generation (called by plugin).

**Auth**: X-API-Key (plugin)

**Body**:
```json
{
  "crystalId": "0x..."
}
```

#### GET /api/merkle/proof/:crystalId
Get Merkle proof for a crystal.

**Response**:
```json
{
  "crystalId": "0x...",
  "proof": ["0x...", "0x..."],
  "root": "0x..."
}
```

### Beacons

#### POST /api/beacon/register
Register single beacon on-chain.

**Auth**: X-API-Key (plugin)

**Body**:
```json
{
  "beaconId": "beacon-uuid",
  "ownerAddress": "0x..."
}
```

#### POST /api/beacon/batch-register
Register multiple beacons (gas efficient).

**Auth**: X-API-Key (plugin)

**Body**:
```json
{
  "beacons": [
    {
      "beaconId": "beacon-uuid-1",
      "ownerAddress": "0x..."
    },
    {
      "beaconId": "beacon-uuid-2",
      "ownerAddress": "0x..."
    }
  ]
}
```

#### GET /api/beacon/:id
Get beacon info.

#### GET /api/beacon/list/active
Get all active beacons.

### Wallet

#### POST /api/wallet/link
Link player's Minecraft UUID to wallet address.

**Auth**: X-API-Key (plugin)

**Body**:
```json
{
  "playerUuid": "minecraft-player-uuid",
  "walletAddress": "0x..."
}
```

#### GET /api/wallet/:playerUuid
Get player's linked wallet address.

**Auth**: X-API-Key (plugin)

### Admin

All admin endpoints require Basic Auth (ADMIN_USERNAME:ADMIN_PASSWORD).

#### POST /api/admin/process-batch
Process pending redemptions.

**Body**:
```json
{
  "limit": 10
}
```

#### POST /api/admin/retry-queued
Move queued redemptions to pending (when gas drops).

#### GET /api/admin/stats
Get redemption statistics.

#### POST /api/admin/merkle/update
Manually trigger Merkle root update.

#### GET /api/admin/redemptions/pending
Get all pending redemptions.

#### GET /api/admin/redemptions/queued
Get all queued redemptions (high gas).

#### GET /api/admin/contract/tax-rates
Get current contract tax rates.

#### POST /api/admin/beacon/deactivate
Deactivate a beacon.

**Body**:
```json
{
  "beaconId": "beacon-uuid"
}
```

#### GET /api/admin/security/failed-attempts
Get recent failed redemption attempts.

**Query**:
- `hours` (default: 24) - Look back period

## Security Features

### Authentication

1. **Plugin Authentication**: API key in `X-API-Key` header
2. **Admin Authentication**: Basic Auth (username:password)

### Rate Limiting

- Global: 100 requests / 15 minutes
- Redemption: 10 requests / hour (per user or IP)
- API: 50 requests / 5 minutes
- Admin: 100 requests / hour

### Ownership Verification

All redemptions verify:
1. Crystal exists in database
2. Requester owns the crystal (`owner_user_id` matches)
3. Crystal not already redeemed
4. Beacon is active
5. Player has linked wallet

### Audit Logging

All redemption attempts logged with:
- User ID
- Crystal ID
- Event type (ownership_failed, queued, pending, completed, failed)
- IP address
- Timestamp
- Details (reason, gas price, etc.)

## Database Schema

### crystals
- `id` (VARCHAR 66) - bytes32 crystal ID
- `beacon_id` - Beacon UUID where found
- `owner_user_id` - Minecraft player UUID
- `owner_address` - Linked wallet address
- `redeemed` - Boolean flag
- `redemption_tx_hash` - Transaction hash

### beacons
- `id` - Beacon UUID
- `owner_user_id` - Landowner player UUID
- `owner_address` - Landowner wallet
- `location_world`, `location_x/y/z` - Coordinates
- `registered_onchain` - Boolean
- `onchain_id` - bytes32 beacon ID

### player_wallets
- `player_uuid` - Minecraft player UUID
- `wallet_address` - Linked Ethereum address

### redemption_queue
- `user_id`, `crystal_id`, `beacon_id`
- `landowner_address`, `user_address`
- `status` - pending, queued, processing, completed, failed
- `tx_hash` - Transaction hash if completed
- `gas_check` - JSON gas data

### redemption_logs
- Audit log for all redemption attempts
- Links to user, crystal, event type, IP, timestamp

## Development

### Running in Development Mode

```bash
npm run dev
```

Uses nodemon for auto-reload on file changes.

### Testing

```bash
npm test
```

### Logging

Logs are written to:
- `logs/app.log` - All logs
- `logs/error.log` - Error logs only
- Console (formatted)

Log levels: error, warn, info, debug

### Manual Operations

**Rebuild Merkle Tree**:
```bash
curl -X POST http://localhost:3000/api/admin/merkle/update \
  -u admin:password
```

**Process Pending Redemptions**:
```bash
curl -X POST http://localhost:3000/api/admin/process-batch \
  -u admin:password \
  -H "Content-Type: application/json" \
  -d '{"limit": 20}'
```

**Check Gas Price**:
```bash
curl http://localhost:3000/api/gas/current
```

## Deployment

### Production Checklist

- [ ] Set `NODE_ENV=production` in .env
- [ ] Use strong `API_SECRET` and `ADMIN_PASSWORD`
- [ ] Server wallet funded with PLS for gas
- [ ] Database secured with strong password
- [ ] RPC endpoint reliable (consider paid tier)
- [ ] Reverse proxy (nginx/Apache) with SSL
- [ ] Process manager (PM2, systemd)
- [ ] Log rotation configured
- [ ] Monitoring and alerts set up
- [ ] Backup strategy for database and Merkle tree files

### Using PM2

```bash
# Install PM2
npm install -g pm2

# Start server
pm2 start server.js --name crystalmath-backend

# View logs
pm2 logs crystalmath-backend

# Restart
pm2 restart crystalmath-backend

# Auto-start on reboot
pm2 startup
pm2 save
```

### Using systemd

Create `/etc/systemd/system/crystalmath-backend.service`:

```ini
[Unit]
Description=CrystalMath Backend API Server
After=network.target

[Service]
Type=simple
User=crystalmath
WorkingDirectory=/opt/crystalmath-backend
ExecStart=/usr/bin/node server.js
Restart=on-failure
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
```

Enable and start:
```bash
sudo systemctl enable crystalmath-backend
sudo systemctl start crystalmath-backend
sudo systemctl status crystalmath-backend
```

## Monitoring

### Health Check

```bash
curl http://localhost:3000/health
```

Response:
```json
{
  "status": "ok",
  "timestamp": "2025-01-02T12:00:00.000Z",
  "uptime": 3600.5
}
```

### Gas Monitoring

Server automatically checks gas every 5 minutes and logs when queued redemptions are ready to process.

### Metrics to Monitor

- Redemption queue size (pending + queued)
- Failed redemption rate
- Average gas price
- Server wallet balance
- API response times
- Database connection pool

## Troubleshooting

### Common Issues

**Database connection failed**:
- Check DB credentials in .env
- Ensure database server is running
- Verify network connectivity

**Contract initialization failed**:
- Check CONTRACT_ADDRESS is correct
- Verify RPC endpoint is accessible
- Ensure SERVER_PRIVATE_KEY is valid

**Merkle root update failed**:
- Check server wallet has PLS for gas
- Verify contract allows server to update root
- Check RPC endpoint not rate limited

**Redemptions stuck in pending**:
- Run admin process-batch endpoint
- Check server wallet has sufficient PLS
- Verify contract is not paused

### Debug Mode

Set environment variable for verbose logging:
```bash
DEBUG=* npm start
```

## License

MIT

## Support

For issues and questions, please refer to the main CrystalMath documentation.
